package dao;

import Conexion.Conexion;
import model.Pokemon;

import java.sql.*;
import java.util.ArrayList;

public class PokemonDAO {

    public static void insertar(String nombre, String tipo) {
        try (Connection con = Conexion.getConnection()) {

            String sql = "INSERT INTO pokemon(nombre, tipo) VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nombre);
            ps.setString(2, tipo);

            ps.executeUpdate();

            System.out.println("Exito...Pokemon registrado correctamente");

        } catch (Exception e) {
            System.out.println("Error al insertar pokemon: " + e.getMessage());
        }
    }

    public static ArrayList<Pokemon> listar() {
        ArrayList<Pokemon> lista = new ArrayList<>();

        try (Connection con = Conexion.getConnection()) {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM pokemon");

            while (rs.next()) {
                Pokemon p = new Pokemon(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("tipo")
                );
                lista.add(p);
            }

        } catch (Exception e) {
            System.out.println("Error al listar pokemon: " + e.getMessage());
        }

        return lista;
    }

    public static void eliminar(int id) {
        try (Connection con = Conexion.getConnection()) {

            String sql = "DELETE FROM pokemon WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("Exito...Pokemon eliminado");

        } catch (Exception e) {
            System.out.println("Error al eliminar: " + e.getMessage());
        }
    }

    public static void actualizar(int id, String nombre, String tipo) {
        try (Connection con = Conexion.getConnection()) {

            String sql = "UPDATE pokemon SET nombre=?, tipo=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nombre);
            ps.setString(2, tipo);
            ps.setInt(3, id);

            ps.executeUpdate();

            System.out.println("Exito...Pokemon actualizado");

        } catch (Exception e) {
            System.out.println("Error al actualizar: " + e.getMessage());
        }
    }
}