import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Pokedex bd = new Pokedex();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n===== MENU POKEDEX =====");
            System.out.println("1. Insertar Pokemon");
            System.out.println("2. Busqueda (Pokemones / Objetos)");
            System.out.println("3. Actualizar Pokemon");
            System.out.println("4. Eliminar obj. Mochila");
            System.out.println("0. Salir");
            System.out.print("Opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.print("Nombre: ");    String nombre = sc.nextLine();
                    System.out.print("Tipo: ");      String tipo   = sc.nextLine();
                    System.out.print("Nivel: ");     int nivel     = sc.nextInt();
                    bd.insertarPokemon(new Pokemon(0, nombre, tipo, nivel));
                }
                case 2 -> {
                    System.out.println("a) Pokemones  b) Objetos");
                    String sub = sc.nextLine().trim().toLowerCase();
                    System.out.print("Buscar: ");
                    String busq = sc.nextLine();
                    if (sub.equals("a")) {
                        List<Pokemon> pokes = bd.buscarPokemones(busq);
                        pokes.forEach(System.out::println);
                    } else {
                        List<Objeto> objs = bd.buscarObjetos(busq);
                        objs.forEach(System.out::println);
                    }
                }
                case 3 -> {
                    System.out.print("ID del Pokemon a actualizar: "); int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Nuevo nombre: ");  String nombre = sc.nextLine();
                    System.out.print("Nuevo tipo: ");    String tipo   = sc.nextLine();
                    System.out.print("Nuevo nivel: ");   int nivel     = sc.nextInt();
                    bd.actualizarPokemon(new Pokemon(id, nombre, tipo, nivel));
                }
                case 4 -> {
                    System.out.print("ID del objeto a eliminar: ");
                    int id = sc.nextInt();
                    bd.eliminarObjetoMochila(id);
                }
            }
        } while (opcion != 0);

        System.out.println("Hasta luego!");
    }
}