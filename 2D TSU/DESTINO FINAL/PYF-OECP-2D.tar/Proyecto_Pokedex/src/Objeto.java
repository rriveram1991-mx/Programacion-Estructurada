public class Objeto {
    private int id;
    private String nombre;
    private int cantidad;
    private String descripcion;

    public Objeto(int id, String nombre, int cantidad, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.descripcion = descripcion;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public int getCantidad() { return cantidad; }
    public String getDescripcion() { return descripcion; }

    @Override
    public String toString() {
        return "Objeto{id=" + id + ", nombre='" + nombre + "', cantidad=" + cantidad +
                ", descripcion='" + descripcion + "'}";
    }
}