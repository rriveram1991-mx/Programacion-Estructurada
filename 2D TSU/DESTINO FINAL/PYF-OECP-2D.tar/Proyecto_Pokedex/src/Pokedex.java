import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Pokedex {

    private static final String URL  = "jdbc:mysql://localhost:3306/Pokedex?useSSL=false&serverTimezone=UTC";;
    private static final String USER = "root";
    private static final String PASS = "Emiliano12@";

    private Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    // ──────────────────────────────────────────
    public void insertarPokemon(Pokemon p) {
        String sql = "INSERT INTO Pokemones (nombre, tipo, nivel) VALUES (?, ?, ?)";
        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getTipo());
            ps.setInt(3, p.getNivel());
            ps.executeUpdate();
            System.out.println("Pokemon insertado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al insertar: " + e.getMessage());
        }
    }


    // ──────────────────────────────────────────
    public List<Pokemon> buscarPokemones(String nombre) {
        List<Pokemon> lista = new ArrayList<>();
        String sql = "SELECT * FROM Pokemones WHERE nombre LIKE ?";
        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + nombre + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Pokemon(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("tipo"),
                        rs.getInt("nivel")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error en búsqueda: " + e.getMessage());
        }
        return lista;
    }


    // ──────────────────────────────────────────
    public List<Objeto> buscarObjetos(String nombre) {
        List<Objeto> lista = new ArrayList<>();
        String sql = "SELECT * FROM Mochila WHERE nombre LIKE ?";
        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + nombre + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Objeto(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getInt("cantidad"),
                        rs.getString("descripcion")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error en búsqueda: " + e.getMessage());
        }
        return lista;
    }


    // ──────────────────────────────────────────
    public void actualizarPokemon(Pokemon p) {
        String sql = "UPDATE Pokemones SET nombre=?, tipo=?, nivel=? WHERE id=?";
        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getTipo());
            ps.setInt(3, p.getNivel());
            ps.setInt(4, p.getId());
            int filas = ps.executeUpdate();
            System.out.println(filas > 0 ? "Pokemon actualizado." : "No se encontró el Pokemon.");
        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
        }
    }


    // ──────────────────────────────────────────
    public void eliminarObjetoMochila(int id) {
        String sql = "DELETE FROM Mochila WHERE id=?";
        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            System.out.println(filas > 0 ? "Objeto eliminado." : "No se encontró el objeto.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
        }
    }
}