package org.example;

import java.sql.*;

public class Mochila {
    private Connection con;

    public Mochila(Connection conexionRecibida) {
        this.con = conexionRecibida;
    }

    public void insertarObjeto(Item i) {

        String sql = "INSERT INTO mochila (nombreobjeto, cantidadobjeto, capacidadmaxima, categoria) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, i.nombre);
            ps.setInt(2, i.cantidad);
            ps.setInt(3, i.capacidad);
            ps.setString(4, i.categoria);
            ps.executeUpdate();
            System.out.println("Objeto guardado con éxito!");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void insertarPokemon(Pokemon p) {
        String sql = "INSERT INTO pokemon (Pokemon, ataque, tipo, nivel) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql); // Ahora 'con' ya existe
            ps.setString(1, p.nombre);
            ps.setInt(2, p.ataque);
            ps.setString(3, p.tipo);
            ps.setInt(4, p.nivel);
            ps.executeUpdate();
            System.out.println("¡Excelente!" + p.nombre + " se unió a tu equipo.");
        } catch (SQLException e) {
            System.out.println("Error al capturar: " + e.getMessage());
        }
    }


    public void mostrarPokedex() {
        String sql = "SELECT * FROM pokemon";

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n======= MI POKÉDEX =======");

            while (rs.next()) {
                int id = rs.getInt("ID_Pokedex");
                String nombre = rs.getString("Pokemon");
                String tipo = rs.getString("tipo");
                int ataque = rs.getInt("ataque");
                int nivel = rs.getInt("nivel");

                System.out.println(String.format("[%d] %-12s | Tipo: %-10s | Atq: %d | Niv: %d",
                        id, nombre, tipo, ataque, nivel));
            }
            System.out.println("==========================\n");

        } catch (SQLException e) {
            System.out.println("Error al leer la base de datos: " + e.getMessage());
        }
    }
    public void mostrarMochila() {
        String sql = "SELECT * FROM mochila";

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n======= CONTENIDO DE LA MOCHILA =======");

            while (rs.next()) {
                int id = rs.getInt("idobjeto");
                String nombre = rs.getString("nombreobjeto");
                int cantidad = rs.getInt("cantidadobjeto");
                int capacidad = rs.getInt("capacidadmaxima");
                String cat = rs.getString("categoria");

                System.out.println(String.format("[%d] %-15s | Cant: %d | Cap: %d | Cat: %s",
                        id, nombre, cantidad, capacidad, cat));
            }
            System.out.println("========================================\n");

        } catch (SQLException e) {
            System.out.println("Error al leer la mochila: " + e.getMessage());
        }
    }

}