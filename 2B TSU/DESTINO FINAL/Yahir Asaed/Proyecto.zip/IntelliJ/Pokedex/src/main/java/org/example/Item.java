package org.example;

public class Item {
    public String nombre;
    public int cantidad;
    public int capacidad;
    public String categoria;

    public Item(String nombre, int cantidad, int capacidad, String categoria) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.capacidad = capacidad;
        this.categoria = categoria;
    }
}