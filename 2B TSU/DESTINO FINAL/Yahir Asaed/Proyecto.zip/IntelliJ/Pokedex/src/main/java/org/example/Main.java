package org.example;

import java.sql.*;
import java.util.Scanner;

public class Main {
    public Main() throws SQLException {
    }
    Connection con = DriverManager.getConnection(url, user, pass);
    static String url = "jdbc:mysql://localhost:3306/pokedexproyecto";
    static String user = "root";
    static String pass = "root";


    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int opcion = 0;

        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            System.out.println("Conexión exitosa a la base de datos.");
            Mochila miMochila = new Mochila(con);
            do {
                System.out.println("\n--- Bienvenido a mi Pokedex ---");
                System.out.println("1. Insertar Pokémon");
                System.out.println("2. Verificar Pokedex");
                System.out.println("3. Ver mochila");
                System.out.println("4. Insertar objetos a la mochila");
                System.out.println("5. Salir");
                System.out.print("Elige una opción: ");
                opcion = leer.nextInt();

                switch (opcion) {
                    case 1:
                        System.out.println("--- REGISTRAR POKÉMON ---");
                        System.out.print("Nombre: ");
                        String nomP = leer.next();
                        System.out.print("Tipo: ");
                        String tipoP = leer.next();
                        System.out.print("Puntos de Ataque: ");
                        int atqP = leer.nextInt();
                        System.out.print("Nivel: ");
                        int nivP = leer.nextInt();

                        Pokemon nuevoP = new Pokemon(nomP, tipoP, atqP, nivP);

                        miMochila.insertarPokemon(nuevoP);
                        break;
                    case 2:
                        System.out.println("--- CONSULTANDO POKÉDEX ---");
                        miMochila.mostrarPokedex();
                        break;
                    case 3:
                        System.out.println("--- ABRIENDO LA MOCHILA... ---");
                        miMochila.mostrarMochila();
                        break;
                    case 4:
                        System.out.println("--- MOCHILA ---");
                        System.out.println("¿Qué objeto desea insertar?");
                        String n = leer.next();
                        System.out.println("¿Qué cantidad del objeto?");
                        int c = leer.nextInt();
                        System.out.println("¿Cuál es la capacidad máxima del objeto?");
                        int cap = leer.nextInt();
                        System.out.println("¿A qué categoría desea meterlo?" +
                                "- Pociones" +
                                "- Pokeballs" +
                                "- Mt's & Tm's" +
                                "- Bayas");
                         String cat = leer.next();

                          Item nuevoItem = new Item(n, c, cap, cat);
                        miMochila.insertarObjeto(nuevoItem);
                        break;

                    case 5:
                        System.out.println("Saliendo del sistema...");
                        break;

                    default:
                        System.out.println("Opción no válida, carnal.");
                        break;
                }
            } while (opcion != 5);

            con.close();

        } catch (Exception e) {
            System.out.println("No se pudo conectar o hubo un error");
            System.out.println("El error es: " + e.getMessage());
        }
    }
}