package org.example;

public class Pokemon {
    public String nombre;
    public String tipo;
    public int ataque;
    public int nivel;

    public Pokemon(String nombre, String tipo, int ataque, int nivel) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.ataque = ataque;
        this.nivel = nivel;
    }
}
