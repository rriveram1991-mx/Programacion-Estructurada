package org.example;

import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion = -1;

        System.out.println("*********************************");
        System.out.println("* POKEDEX - Roberto Lopez *");
        System.out.println("*********************************");

        while (opcion != 0) {
            System.out.println("\n== MENU PRINCIPAL ==");
            System.out.println("1. Registrar Pokemon");
            System.out.println("2. Ver Pokemones");
            System.out.println("3. Eliminar Pokemon");
            System.out.println("4. Actualizar Pokemon");
            System.out.println("5. Gestion de Mochila");
            System.out.println("0. Salir");
            System.out.print("Elige: ");

            opcion = Integer.parseInt(scanner.nextLine());

            try {
                Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/sistema_pokemon", "root", "");

                switch (opcion) {
                    case 1:
                        System.out.print("Nombre del Pokemon: ");
                        String nombre = scanner.nextLine();
                        System.out.print("Tipo: ");
                        String tipo = scanner.nextLine();
                        System.out.print("Nivel: ");
                        int nivel = Integer.parseInt(scanner.nextLine());
                        System.out.print("PS Maximos: ");
                        int ps = Integer.parseInt(scanner.nextLine());
                        PreparedStatement ps1 = con.prepareStatement(
                                "INSERT INTO pokemones(nombre,tipo,nivel,ps_maximos) VALUES(?,?,?,?)");
                        ps1.setString(1, nombre);
                        ps1.setString(2, tipo);
                        ps1.setInt(3, nivel);
                        ps1.setInt(4, ps);
                        ps1.executeUpdate();
                        System.out.println("Pokemon registrado!");
                        break;
                    case 2:
                        ResultSet rs2 = con.createStatement()
                                .executeQuery("SELECT * FROM pokemones");
                        System.out.println("\nID | Nombre | Tipo | Nivel | PS");
                        while (rs2.next()) {
                            System.out.println(rs2.getInt("id_pokemon") + " | " +
                                    rs2.getString("nombre") + " | " +
                                    rs2.getString("tipo") + " | " +
                                    rs2.getInt("nivel") + " | " +
                                    rs2.getInt("ps_maximos"));
                        }
                        break;
                    case 3:
                        System.out.print("ID del Pokemon a eliminar: ");
                        int id3 = Integer.parseInt(scanner.nextLine());
                        PreparedStatement ps3 = con.prepareStatement(
                                "DELETE FROM pokemones WHERE id_pokemon=?");
                        ps3.setInt(1, id3);
                        ps3.executeUpdate();
                        System.out.println("Pokemon eliminado!");
                        break;
                    case 4:
                        System.out.print("ID del Pokemon a actualizar: ");
                        int id4 = Integer.parseInt(scanner.nextLine());
                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = scanner.nextLine();
                        System.out.print("Nuevo nivel: ");
                        int nuevoNivel = Integer.parseInt(scanner.nextLine());
                        PreparedStatement ps4 = con.prepareStatement(
                                "UPDATE pokemones SET nombre=?, nivel=? WHERE id_pokemon=?");
                        ps4.setString(1, nuevoNombre);
                        ps4.setInt(2, nuevoNivel);
                        ps4.setInt(3, id4);
                        ps4.executeUpdate();
                        System.out.println("Pokemon actualizado!");
                        break;
                    case 5:
                        int opMochila = -1;
                        while (opMochila != 0) {
                            System.out.println("\n== MOCHILA ==");
                            System.out.println("1. Agregar objeto");
                            System.out.println("2. Ver objetos");
                            System.out.println("3. Eliminar objeto");
                            System.out.println("4. Actualizar objeto");
                            System.out.println("0. Volver");
                            System.out.print("Elige: ");
                            opMochila = Integer.parseInt(scanner.nextLine());

                            switch (opMochila) {
                                case 1:
                                    System.out.print("Nombre del objeto: ");
                                    String objNombre = scanner.nextLine();
                                    System.out.print("Cantidad: ");
                                    int cantidad = Integer.parseInt(scanner.nextLine());
                                    System.out.print("Descripcion: ");
                                    String desc = scanner.nextLine();
                                    PreparedStatement pm1 = con.prepareStatement(
                                            "INSERT INTO mochila(nombre_objeto,cantidad,descripcion) VALUES(?,?,?)");
                                    pm1.setString(1, objNombre);
                                    pm1.setInt(2, cantidad);
                                    pm1.setString(3, desc);
                                    pm1.executeUpdate();
                                    System.out.println("Objeto agregado!");
                                    break;
                                case 2:
                                    ResultSet rm2 = con.createStatement()
                                            .executeQuery("SELECT * FROM mochila");
                                    System.out.println("\nID | Objeto | Cantidad | Descripcion");
                                    while (rm2.next()) {
                                        System.out.println(rm2.getInt("id_objeto") + " | " +
                                                rm2.getString("nombre_objeto") + " | " +
                                                rm2.getInt("cantidad") + " | " +
                                                rm2.getString("descripcion"));
                                    }
                                    break;
                                case 3:
                                    System.out.print("ID del objeto a eliminar: ");
                                    int idm3 = Integer.parseInt(scanner.nextLine());
                                    PreparedStatement pm3 = con.prepareStatement(
                                            "DELETE FROM mochila WHERE id_objeto=?");
                                    pm3.setInt(1, idm3);
                                    pm3.executeUpdate();
                                    System.out.println("Objeto eliminado!");
                                    break;
                                case 4:
                                    System.out.print("ID del objeto a actualizar: ");
                                    int idm4 = Integer.parseInt(scanner.nextLine());
                                    System.out.print("Nuevo nombre: ");
                                    String nuevoObj = scanner.nextLine();
                                    System.out.print("Nueva cantidad: ");
                                    int nuevaCant = Integer.parseInt(scanner.nextLine());
                                    PreparedStatement pm4 = con.prepareStatement(
                                            "UPDATE mochila SET nombre_objeto=?, cantidad=? WHERE id_objeto=?");
                                    pm4.setString(1, nuevoObj);
                                    pm4.setInt(2, nuevaCant);
                                    pm4.setInt(3, idm4);
                                    pm4.executeUpdate();
                                    System.out.println("Objeto actualizado!");
                                    break;
                                case 0:
                                    System.out.println("Volviendo...");
                                    break;
                            }
                        }
                        break;
                    case 0:
                        System.out.println("Hasta luego!");
                        break;
                }
                con.close();
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}