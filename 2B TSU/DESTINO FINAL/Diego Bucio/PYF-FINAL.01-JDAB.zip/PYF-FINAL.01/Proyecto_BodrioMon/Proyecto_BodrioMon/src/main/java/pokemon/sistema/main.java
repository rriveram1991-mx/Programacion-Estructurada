package pokemon.sistema;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

/**
 * Institución: Universidad Tecnológica de Torreón.
 * Carrera: Ingeniería en Desarrollo de Software.
 * Alumno: [Juan Diego Arroyo Bucio.]
 * Materia: Programación Estructurada.
 */
public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = false;

        System.out.println("=== TERMINAL DEL PROFESOR OAK ===");

        while (!salir) {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Insertar Pokemones o Ítems");
            System.out.println("2. Leer Pokemones y Mochila");
            System.out.println("3. Eliminar Pokemones");
            System.out.println("4. Actualizar Pokemones o Mochila");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");

            int opcion = sc.nextInt();
            sc.nextLine(); // Limpiar el Enter fantasma

            switch (opcion) {
                case 1:
                    insertarDatos(sc);
                    break;
                case 2:
                    leerDatos();
                    break;
                case 3:
                    eliminarPokemon(sc);
                    break;
                case 4:
                    actualizarDatos(sc);
                    break;
                case 5:
                    salir = true;
                    System.out.println("Apagando terminal... ¡Suerte en tu viaje Pokémon, Bucio!");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
        sc.close();
    }

    // --- MÉTODOS DEL CRUD ---

    // 1. INSERTAR (Create)
    private static void insertarDatos(Scanner sc) {
        System.out.println("\n1. Agregar Pokemon | 2. Agregar Objeto a Mochila");
        int subOpcion = sc.nextInt();
        sc.nextLine();

        try (Connection con = conexion.getConexion()) {
            if (subOpcion == 1) {
                System.out.print("Nombre del Pokemon: ");
                String nombre = sc.nextLine();
                System.out.print("Tipo: ");
                String tipo = sc.nextLine();
                System.out.print("Nivel: ");
                int nivel = sc.nextInt();

                String sql = "INSERT INTO pokemones (nombre, tipo, nivel) VALUES (?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, nombre);
                ps.setString(2, tipo);
                ps.setInt(3, nivel);
                ps.executeUpdate();
                System.out.println("¡Pokemon registrado en la Pokedex!");

            } else if (subOpcion == 2) {
                System.out.print("Nombre del Objeto: ");
                String nombreObj = sc.nextLine();
                System.out.print("Cantidad: ");
                int cant = sc.nextInt();

                String sql = "INSERT INTO mochila (nombre_objeto, cantidad) VALUES (?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, nombreObj);
                ps.setInt(2, cant);
                ps.executeUpdate();
                System.out.println("¡Objeto guardado en la mochila!");
            }
        } catch (Exception e) {
            System.out.println("Error al insertar: " + e.getMessage());
        }
    }

    // 2. LEER (Read)
    private static void leerDatos() {
        // Se corrigió "Conexion" a "conexion" con minúscula
        try (Connection con = conexion.getConexion()) {
            System.out.println("\n--- POKEDEX ACTUAL ---");
            String sqlPoke = "SELECT * FROM pokemones";
            PreparedStatement psPoke = con.prepareStatement(sqlPoke);
            ResultSet rsPoke = psPoke.executeQuery();
            while (rsPoke.next()) {
                System.out.println("ID: " + rsPoke.getInt("id") + " | " + rsPoke.getString("nombre") + " | Tipo: " + rsPoke.getString("tipo") + " | Nivel: " + rsPoke.getInt("nivel"));
            }

            System.out.println("\n--- TU MOCHILA ---");
            String sqlMochila = "SELECT * FROM mochila";
            PreparedStatement psMochila = con.prepareStatement(sqlMochila);
            ResultSet rsMochila = psMochila.executeQuery();
            while (rsMochila.next()) {
                System.out.println("ID: " + rsMochila.getInt("id") + " | Objeto: " + rsMochila.getString("nombre_objeto") + " | Cantidad: " + rsMochila.getInt("cantidad"));
            }
        } catch (Exception e) {
            System.out.println("Error al leer datos: " + e.getMessage());
        }
    }

    // 3. ELIMINAR (Delete)
    private static void eliminarPokemon(Scanner sc) {
        System.out.print("\nIngresa el ID del Pokemon que deseas liberar (eliminar): ");
        int id = sc.nextInt();

        try (Connection con = conexion.getConexion()) {
            String sql = "DELETE FROM pokemones WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            int filas = ps.executeUpdate();

            if (filas > 0) System.out.println("Pokemon liberado exitosamente.");
            else System.out.println("No se encontró ningún Pokemon con ese ID.");
        } catch (Exception e) {
            System.out.println("Error al eliminar: " + e.getMessage());
        }
    }

    private static void actualizarDatos(Scanner sc) {
        System.out.println("\n1. Subir nivel de Pokemon | 2. Actualizar cantidad de objetos");
        int subOpcion = sc.nextInt();
        sc.nextLine(); // IMPORTANTE: Limpiar el buffer después de un nextInt

        try (Connection con = conexion.getConexion()) { // Revisa que sea la clase correcta
            if (subOpcion == 1) {
                System.out.print("ID del Pokemon a actualizar: ");
                int id = sc.nextInt();
                System.out.print("Nuevo nivel: ");
                int nuevoNivel = sc.nextInt();

                String sql = "UPDATE pokemones SET nivel = ? WHERE id = ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, nuevoNivel);
                ps.setInt(2, id);

                // executeUpdate devuelve un número: cuántas filas cambió
                int filas = ps.executeUpdate();

                if (filas > 0) {
                    System.out.println("¡Nivel actualizado con éxito! (Filas afectadas: " + filas + ")");
                } else {
                    System.out.println("⚠️ Ojo: No se encontró ningún Pokemon con el ID: " + id);
                }

            } else if (subOpcion == 2) {
                System.out.print("ID del objeto en mochila: ");
                int id = sc.nextInt();
                System.out.print("Nueva cantidad: ");
                int nuevaCant = sc.nextInt();

                String sql = "UPDATE mochila SET cantidad = ? WHERE id = ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, nuevaCant);
                ps.setInt(2, id);

                int filas = ps.executeUpdate();

                if (filas > 0) {
                    System.out.println("¡Mochila actualizada con éxito!");
                } else {
                    System.out.println("⚠️ Ojo: No se encontró el objeto con ID: " + id);
                }
            }
        } catch (Exception e) {
            System.out.println("Error crítico al actualizar: " + e.getMessage());
        }
    }
}