package pokemon.sistema;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Institución: Universidad Tecnológica de Torreón.
 * Carrera: Ingeniería en Desarrollo de Software.
 * Alumno: [Juan Diego Arroyo Bucio.]
 * Materia: Programación Estructurada.
 */
public class conexion {

    // Se eliminó el "public static void main" que envolvía este método
    public static Connection getConexion() {
        Connection conexion = null;
        var url = "jdbc:mysql://localhost:3306/proyecto_pokemon";
        var usuario = "root";
        var pass = "123456789"; // Tu contraseña de siempre

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(url, usuario, pass);
        } catch (Exception e) {
            System.out.println("Error al conectar a la BD: " + e.getMessage());
        }
        return conexion;
    }
}