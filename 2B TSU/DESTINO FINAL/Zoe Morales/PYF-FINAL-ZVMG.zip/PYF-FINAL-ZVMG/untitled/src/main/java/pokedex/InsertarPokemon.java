package pokedex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class InsertarPokemon {

    public static void insertar() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Nombre del pokemon: ");
        String nombre = sc.nextLine();

        System.out.print("Tipo: ");
        String tipo = sc.nextLine();

        System.out.print("Nivel: ");
        int nivel = sc.nextInt();

        Connection con = Conexion.getConnection();

        try {
            String sql = "INSERT INTO pokemones (nombre, tipo, nivel) VALUES (?, ?, ?)";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, nombre);
            pst.setString(2, tipo);
            pst.setInt(3, nivel);

            pst.executeUpdate();

            System.out.println("Pokemon insertado correctamente");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
