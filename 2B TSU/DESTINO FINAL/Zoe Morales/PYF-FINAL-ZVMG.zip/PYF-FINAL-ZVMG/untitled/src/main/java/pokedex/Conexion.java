package pokedex;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    public static Connection getConnection() {
        Connection con = null;

        try {
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/pokedex",
                    "root",
                    "moragazoevale"
            );
        } catch (Exception e) {
            System.out.println("Error de conexion: " + e.getMessage());
        }

        return con;
    }
}
