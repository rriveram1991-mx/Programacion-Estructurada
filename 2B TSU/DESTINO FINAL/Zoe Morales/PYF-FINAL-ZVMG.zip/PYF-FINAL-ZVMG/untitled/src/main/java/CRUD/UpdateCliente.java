package CRUD;
import gym.Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class UpdateCliente {
    public static void UpdateCliente() {
        try {
            Connection con = Conexion.getConnection();
            String sql = "UPDATE alumnos SET nombre=?, edad=?, membresia=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "suki");
            ps.setInt(2, 100);
            ps.setString(3, "GOLD PLUS");
            ps.setInt(4, 1);
            ps.executeUpdate();
            System.out.println("Cliente actualizado correctamente");
            System.out.println();
            ps.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
        public static void main(String[] args) {
            UpdateCliente();}
}
