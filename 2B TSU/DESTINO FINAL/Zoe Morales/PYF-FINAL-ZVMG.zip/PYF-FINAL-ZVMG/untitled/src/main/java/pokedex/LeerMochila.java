package pokedex;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class LeerMochila {

    public static void leer() {

        Connection con = Conexion.getConnection();

        try {
            String sql = "SELECT * FROM mochila";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Objeto: " + rs.getString("objeto"));
                System.out.println("Cantidad: " + rs.getInt("cantidad"));
                System.out.println("----------------------");
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}