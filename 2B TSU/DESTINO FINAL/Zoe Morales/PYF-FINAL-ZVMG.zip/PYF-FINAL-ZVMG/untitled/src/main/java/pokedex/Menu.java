package pokedex;

import java.util.Scanner;

public class Menu {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- MENU POKEDEX ---");
            System.out.println("1. Insertar");
            System.out.println("2. Leer");
            System.out.println("3. Eliminar Pokemon");
            System.out.println("4. Actualizar");
            System.out.println("5. Salir");
            System.out.print("Opcion: ");

            opcion = sc.nextInt();

            switch (opcion) {

                case 1:
                    System.out.println("1. Insertar Pokemon");
                    System.out.println("2. Insertar Mochila");
                    int opInsert = sc.nextInt();

                    if (opInsert == 1) {
                        InsertarPokemon.insertar();
                    } else if (opInsert == 2) {
                        InsertarMochila.insertar();
                    } else {
                        System.out.println("Opcion invalida");
                    }
                    break;

                case 2:
                    System.out.println("1. Leer Pokemones");
                    System.out.println("2. Leer Mochila");
                    int opLeer = sc.nextInt();

                    if (opLeer == 1) {
                        LeerPokemon.leer();
                    } else if (opLeer == 2) {
                        LeerMochila.leer();
                    } else {
                        System.out.println("Opcion invalida");
                    }
                    break;

                case 3:
                    EliminarPokemon.eliminar();
                    break;

                case 4:
                    System.out.println("1. Actualizar Pokemon");
                    System.out.println("2. Actualizar Mochila");
                    int opAct = sc.nextInt();

                    if (opAct == 1) {
                        ActualizarPokemon.actualizar();
                    } else if (opAct == 2) {
                        ActualizarMochila.actualizar();
                    } else {
                        System.out.println("Opcion invalida");
                    }
                    break;

                case 5:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opcion invalida");
            }

        } while (opcion != 5);
    }
}
