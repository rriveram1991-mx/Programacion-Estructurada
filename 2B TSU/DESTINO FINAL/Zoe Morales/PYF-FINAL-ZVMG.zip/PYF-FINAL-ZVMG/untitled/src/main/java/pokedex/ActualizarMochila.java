package pokedex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class ActualizarMochila {

    public static void actualizar() {

        Scanner sc = new Scanner(System.in);

        System.out.print("ID del objeto: ");
        int id = sc.nextInt();

        System.out.print("Nueva cantidad: ");
        int cantidad = sc.nextInt();

        Connection con = Conexion.getConnection();

        try {
            String sql = "UPDATE mochila SET cantidad = ? WHERE id = ?";
            PreparedStatement pst = con.prepareStatement(sql);

            pst.setInt(1, cantidad);
            pst.setInt(2, id);

            int filas = pst.executeUpdate();

            if (filas > 0) {
                System.out.println("Cantidad actualizada");
            } else {
                System.out.println("No se encontró el ID");
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
