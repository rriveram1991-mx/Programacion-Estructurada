package pokedex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class InsertarMochila {

    public static void insertar() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Nombre del objeto: ");
        String objeto = sc.nextLine();

        System.out.print("Cantidad: ");
        int cantidad = sc.nextInt();

        Connection con = Conexion.getConnection();

        try {
            String sql = "INSERT INTO mochila (objeto, cantidad) VALUES (?, ?)";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, objeto);
            pst.setInt(2, cantidad);

            pst.executeUpdate();

            System.out.println("Objeto agregado a la mochila");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}