package gym.Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    public static Connection getConnection() {
        Connection conexion = null;

        String baseDatos = "escuela";
        String url = "jdbc:mysql://localhost:3306/" + baseDatos;
        String usuario = "root";
        String password = "moragazoevale";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(url, usuario, password);
        } catch (Exception e) {
            System.out.println("Error al conectarse: " + e.getMessage());
        }

        return conexion;
    }

    public static void main(String[] args) {
        Connection conn = Conexion.getConnection();

        if (conn != null) {
            System.out.println("Conexión exitosa " + conn);
        } else {
            System.out.println("Error en la conexión ");
        }
    }
}
