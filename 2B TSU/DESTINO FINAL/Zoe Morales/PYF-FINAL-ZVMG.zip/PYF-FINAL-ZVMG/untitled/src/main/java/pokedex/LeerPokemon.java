package pokedex;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class LeerPokemon {

    public static void leer() {

        Connection con = Conexion.getConnection();

        try {
            String sql = "SELECT * FROM pokemones";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Nombre: " + rs.getString("nombre"));
                System.out.println("Tipo: " + rs.getString("tipo"));
                System.out.println("Nivel: " + rs.getInt("nivel"));
                System.out.println("----------------------");
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}