package CRUD;
import gym.Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class ReadCliente {
    public static void ReadCliente() {
        Connection con = Conexion.getConnection();
        try {
            Statement st = con.createStatement();
            ResultSet rsCount = st.executeQuery("SELECT COUNT(*) AS total FROM alumnos");
            if (rsCount.next()) {
                int total = rsCount.getInt("total");
                System.out.println("Total de clientes del sistema: " + total);
                System.out.println();
            }
            ResultSet rs = st.executeQuery("SELECT * FROM alumnos");
            System.out.println("INFO DE CLIENTES");
            System.out.println();
            while (rs.next()) {
                System.out.println("# Cliente: " + rs.getInt("id"));
                System.out.println("Nombre de Cliente: " + rs.getString("nombre"));
                System.out.println("Edad de Cliente: " + rs.getInt("edad"));
                System.out.println("Tipo de membresia: " + rs.getString("membresia"));
            }
            rs.close();
            st.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }
}
