package pokedex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class ActualizarPokemon {

    public static void actualizar() {

        Scanner sc = new Scanner(System.in);

        System.out.print("ID del pokemon a actualizar: ");
        int id = sc.nextInt();

        System.out.print("Nuevo nivel: ");
        int nivel = sc.nextInt();

        Connection con = Conexion.getConnection();

        try {
            String sql = "UPDATE pokemones SET nivel = ? WHERE id = ?";
            PreparedStatement pst = con.prepareStatement(sql);

            pst.setInt(1, nivel);
            pst.setInt(2, id);

            int filas = pst.executeUpdate();

            if (filas > 0) {
                System.out.println("Nivel actualizado correctamente");
            } else {
                System.out.println("No se encontró el ID");
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
