package CRUD;
import gym.Conexion.Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
public class InsertarCliente {
    public static void main(String[] args) {
        Connection cox = Conexion.getConnection();
        try{
            String sql="INSERT INTO alumnos (nombre, edad, membresia) VALUES (?,?,?)";
            PreparedStatement pst=cox.prepareStatement(sql);
            pst.setString(1, "Zoe");
            pst.setInt(2, 46);
            pst.setString(3, "Si");
            pst.executeUpdate();
            System.out.println("Registro insertado exitosamente");

        } catch (Exception e) {
           System.out.println("Error al insertar el registro"+ e.getMessage());
        }

    }
}
