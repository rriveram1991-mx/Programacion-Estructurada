package crud_2b;

import java.util.Scanner;

public class prueba_conexion {
    public static void main(String[] args) {
        cafe miCafe = new cafe();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n********** MENÚ CAFETERÍA **********");
            System.out.println("1. Registrar nuevo producto");
            System.out.println("2. Ver menú completo");
            System.out.println("3. Actualizar precio");
            System.out.println("4. Eliminar producto");
            System.out.println("5. Salir");
            System.out.print("Selecciona una opción: ");

            opcion = sc.nextInt();
            sc.nextLine(); // Limpieza de buffer

            switch (opcion) {
                case 1 -> miCafe.registrarProducto();
                case 2 -> miCafe.mostrarMenu();
                case 3 -> miCafe.actualizarPrecio();
                case 4 -> miCafe.eliminarProducto();
                case 5 -> System.out.println("Saliendo... ¡Buen día!");
                default -> System.out.println("❌ Opción inválida.");
            }
        } while (opcion != 5);
    }
}





