package crud_2b;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement; // Import fundamental para insertar y borrar

public class cafe {

    public void registrarProducto() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n--- Registro de Nuevo Café ---");
        System.out.print("Nombre: ");
        String nom = sc.nextLine();
        System.out.print("Categoría (Bebida/Postre): ");
        String cat = sc.nextLine();
        System.out.print("Tamaño: ");
        String tam = sc.nextLine();
        System.out.print("Precio: ");
        double pre = sc.nextDouble();

        String sql = "INSERT INTO menu (nombre, categoria, tamano, precio) VALUES (?, ?, ?, ?)";

        try (Connection con = conexion.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, nom);
            pst.setString(2, cat);
            pst.setString(3, tam);
            pst.setDouble(4, pre);

            pst.executeUpdate();
            System.out.println("✅ ¡Café guardado en la base de datos!");
        } catch (SQLException e) {
            System.out.println("❌ Error al guardar: " + e.getMessage());
        }
    }

    public void mostrarMenu() {
        String sql = "SELECT * FROM menu";
        try (Connection con = conexion.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            System.out.println("\n--- MENÚ ACTUAL ---");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                        " | Nombre: " + rs.getString("nombre") +
                        " | precio: $" + rs.getDouble("precio"));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al leer datos: " + e.getMessage());
        }
    }

    public void actualizarPrecio() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce el ID del producto a modificar: ");
        int id = sc.nextInt();
        System.out.print("Nuevo precio: ");
        double nuevoPre = sc.nextDouble();

        String sql = "UPDATE menu SET precio = ? WHERE id = ?";

        try (Connection con = conexion.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setDouble(1, nuevoPre);
            pst.setInt(2, id);

            int filas = pst.executeUpdate();
            if (filas > 0) System.out.println("✅ Precio actualizado.");
            else System.out.println("⚠️ No se encontró el ID.");

        } catch (SQLException e) {
            System.out.println("❌ Error al actualizar: " + e.getMessage());
        }
    }

    public void eliminarProducto() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nID del producto a eliminar: ");
        int id = sc.nextInt();

        String sql = "DELETE FROM menu WHERE id = ?";

        try (Connection con = conexion.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, id);
            pst.executeUpdate();
            System.out.println("🗑️ Producto eliminado.");

        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar: " + e.getMessage());
        }
    }
}