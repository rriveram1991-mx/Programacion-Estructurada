package CRUD;
import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class updatepok {
    public void actualizarNivel(int id, int nuevoNivel) {
        String sql = "UPDATE pokemones SET nivel = ? WHERE id_pokemon = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, nuevoNivel);
            ps.setInt(2, id);
            int filasAffected = ps.executeUpdate();
            if (filasAffected > 0) {
                System.out.println("¡Nivel actualizado con éxito!");
            } else {
                System.out.println("No se encontró ningún Pokemon con el ID: " + id);
            }
        } catch (Exception e) {
            System.out.println("Error al actualizar: " + e.getMessage());
        }
    }
}

