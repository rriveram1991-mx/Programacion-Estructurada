package CRUD;
import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
public class createpok {
    public void guardarPokemon(String nombre, String tipo, int nivel) {
        String sql = "INSERT INTO pokemones (nombre, tipo, nivel) VALUES (?, ?, ?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, tipo);
            ps.setInt(3, nivel);
            ps.executeUpdate();
            System.out.println("¡Pokemon guardado en la base de datos!");
        } catch (Exception e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }
}