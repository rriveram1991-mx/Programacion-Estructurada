package CRUD;
import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class mochila {
    public void agregarItem(String nombre, int cantidad) {
        String sql = "INSERT INTO mochila (nombre_item, cantidad) VALUES (?, ?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setInt(2, cantidad);
            ps.executeUpdate();
            System.out.println("Objeto guardado en la mochila");
        } catch (Exception e) {
            System.out.println("Error al guardar en mochila: " + e.getMessage());
        }
    }
    public void verMochila() {
        String sql = "SELECT * FROM mochila";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("\n--- CONTENIDO DE LA MOCHILA ---");
            System.out.printf("%-5s | %-15s | %-10s%n", "ID", "OBJETO", "CANTIDAD");
            System.out.println("---------------------------------------");

            while (rs.next()) {
                System.out.printf("%-5d | %-15s | %-10d%n",
                        rs.getInt("id_item"),
                        rs.getString("nombre_item"),
                        rs.getInt("cantidad"));
            }
        } catch (Exception e) {
            System.out.println("Error al leer la mochila: " + e.getMessage());
        }
    }
}
