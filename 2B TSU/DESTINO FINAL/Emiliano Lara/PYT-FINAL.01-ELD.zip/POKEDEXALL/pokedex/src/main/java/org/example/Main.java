package org.example;
import CRUD.createpok;
import CRUD.updatepok;
import CRUD.deletepok;
import CRUD.mochila;
import java.util.Scanner;
public class Main {
    static void main() {
        Scanner leer = new Scanner(System.in);
        int opcion = 0;
        createpok creador = new createpok();
        updatepok editor = new updatepok();
        deletepok eliminador = new deletepok();
        mochila mochilapok = new mochila();
        System.out.println("=== BIENVENIDO A LA POKEDEX SQL ===");
        while (opcion != 5) {
            System.out.println("\n--- MENÚ DE OPCIONES ---");
            System.out.println("1. Registrar nuevo Pokemon");
            System.out.println("2. Actualizar nivel de Pokemon");
            System.out.println("3. Eliminar Pokemon");
            System.out.println("4. Ver Mochila");
            System.out.println("5. Salir");
            System.out.print("Selecciona una opción: ");
            opcion = leer.nextInt();
            leer.nextLine();
            switch (opcion) {
                case 1:
                    System.out.print("Nombre del Pokemon: ");
                    String nombre = leer.nextLine();
                    System.out.print("Tipo: ");
                    String tipo = leer.nextLine();
                    System.out.print("Nivel inicial: ");
                    int nivel = leer.nextInt();
                    creador.guardarPokemon(nombre, tipo, nivel);
                    break;
                case 2:
                    System.out.print("Ingresa el ID del Pokemon a actualizar: ");
                    int idUpdate = leer.nextInt();
                    System.out.print("Ingresa el NUEVO nivel:");
                    int nuevoNivel = leer.nextInt();
                    editor.actualizarNivel(idUpdate, nuevoNivel);
                    break;
                case 3:
                    System.out.print("Ingresa el ID del Pokemon que deseas liberar: ");
                    int idDelete = leer.nextInt();
                    System.out.print("¿Estás seguro? (1 para Sí / 0 para No): ");
                    int confirmar = leer.nextInt();
                    if (confirmar == 1) {
                        eliminador.liberarPokemon(idDelete);
                    } else {
                        System.out.println("Operación cancelada.");
                    }
                    break;
                case 4:
                    System.out.println("\n1. Ver mochila");
                    System.out.println("2. Agregar nuevo objeto");
                    System.out.print("Selecciona: ");
                    int subOpcion = leer.nextInt();
                    leer.nextLine();
                    if (subOpcion == 1) {
                        mochilapok.verMochila();
                    } else if (subOpcion == 2) {
                        System.out.print("Nombre del objeto (ej. Pokebola): ");
                        String item = leer.nextLine();
                        System.out.print("Cantidad: ");
                        int cant = leer.nextInt();
                        leer.nextLine();
                        mochilapok.agregarItem(item, cant);
                    }
                    break;
                case 5:
                    System.out.println("Cerrando Pokedex...");
                    break;
                default:
                    System.out.println("Opción no válida, intenta de nuevo.");
            }
        }
        leer.close();
    }
}

