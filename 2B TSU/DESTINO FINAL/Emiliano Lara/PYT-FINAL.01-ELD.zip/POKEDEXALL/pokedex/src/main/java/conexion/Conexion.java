package conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Conexion {
    public static Connection getConnection() {
        Connection cox = null;
        String bd = "pokedex_db";
        String url = "jdbc:mysql://localhost:3306/" + bd;
        String usr = "root";
        String psd = "lara9090";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cox = DriverManager.getConnection(url, usr, psd);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return cox;
    }
    public static void main(String[] args) {
        Connection prueba = getConnection();
        if (prueba != null) {
            System.out.println("Conexión exitosa ");
        } else {
            System.out.println("Fallo en la conexión.");
        }
    }
}