package CRUD;
import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class deletepok {
    public void liberarPokemon(int id) {
        String sql = "DELETE FROM pokemones WHERE id_pokemon = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Pokemon liberado...");
            } else {
                System.out.println("ID no encontrado.");
            }

        } catch (Exception e) {
            System.out.println("Error al eliminar: " + e.getMessage());
        }
    }
}