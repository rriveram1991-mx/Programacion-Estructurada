package Mochila;

import Pokedex_Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class EliminarBag {

    public static void EliminarBag() {

        Scanner sc = new Scanner(System.in);

        System.out.print("ID del objeto a eliminar: ");
        int id = sc.nextInt();

        try {
            Connection cx = Conexion.getConexion();
            String sql = "DELETE FROM bag WHERE idbag=?";
            PreparedStatement ps = cx.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Objeto eliminado correctamente");
            ps.close();
            cx.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        EliminarBag();
        LeerBag.LeerBag();
    }
}