package Pokemones;

import Pokedex_Conexion.Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class ActualizarPokemon {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Connection cx = Conexion.getConexion();

        try {

            System.out.print("ID del Pokemon a actualizar: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.println("Que deseas actualizar?");
            System.out.println("1. Nombre");
            System.out.println("2. Tipo");
            System.out.println("3. Vida");
            System.out.println("4. Ataque");

            int op = sc.nextInt();
            sc.nextLine();

            String sql = "";
            PreparedStatement ps;

            switch (op) {

                case 1:
                    System.out.print("Nuevo nombre: ");
                    String nombre = sc.nextLine();

                    sql = "UPDATE pokemones SET Nombre=? WHERE ID_Pokemon=?";
                    ps = cx.prepareStatement(sql);
                    ps.setString(1, nombre);
                    ps.setInt(2, id);
                    ps.executeUpdate();
                    break;

                case 2:
                    System.out.print("Nuevo tipo: ");
                    String tipo = sc.nextLine();

                    sql = "UPDATE pokemones SET Tipo=? WHERE ID_Pokemon=?";
                    ps = cx.prepareStatement(sql);
                    ps.setString(1, tipo);
                    ps.setInt(2, id);
                    ps.executeUpdate();
                    break;

                case 3:
                    System.out.print("Nueva vida: ");
                    int vida = sc.nextInt();

                    sql = "UPDATE pokemones SET Vida=? WHERE ID_Pokemon=?";
                    ps = cx.prepareStatement(sql);
                    ps.setInt(1, vida);
                    ps.setInt(2, id);
                    ps.executeUpdate();
                    break;

                case 4:
                    System.out.print("Nuevo ataque: ");
                    int ataque = sc.nextInt();

                    sql = "UPDATE pokemones SET Ataque=? WHERE ID_Pokemon=?";
                    ps = cx.prepareStatement(sql);
                    ps.setInt(1, ataque);
                    ps.setInt(2, id);
                    ps.executeUpdate();
                    break;

                default:
                    System.out.println("Opcion invalida");
            }

            System.out.println("Dato actualizado correctamente");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}