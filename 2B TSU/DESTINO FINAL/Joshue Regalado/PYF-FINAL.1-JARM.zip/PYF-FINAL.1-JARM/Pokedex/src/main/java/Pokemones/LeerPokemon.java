package Pokemones;

import Pokedex_Conexion.Conexion;

import java.sql.*;

public class LeerPokemon {
    public static void LeerPokemon(){
        Connection cx = Conexion.getConexion();
        try {
            Statement st = cx.createStatement();
            ResultSet rsCount = st.executeQuery("SELECT COUNT(*) AS total FROM pokemones");
            if(rsCount.next()){
                int total = rsCount.getInt("total");
                System.out.println("Total de pokemones: "+total);
                System.out.println();
            }
            ResultSet rs = st.executeQuery("SELECT * FROM pokemones");
            System.out.println("INFORMACION DE POKEMONES");
            System.out.println();
            while (rs.next()){
                System.out.println("# Pokemon: "+rs.getInt("ID_Pokemon"));
                System.out.println("Nombre del pokemon: "+rs.getString("Nombre"));
                System.out.println("Tipo del pokemon: "+rs.getString("Tipo"));
                System.out.println("Vida del pokemon: "+rs.getInt("Vida"));
                System.out.println("Ataque del pokemon: "+rs.getInt("Ataque"));
                System.out.println();
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public static void main(String[] args) {
        LeerPokemon();
    }
}
