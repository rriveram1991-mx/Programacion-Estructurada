package Pokemones;

import Pokedex_Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.util.Scanner;

public class InsertarPokemon {
    public static void main(String[] args) {
        Connection cx = Conexion.getConexion();
        Scanner sc = new Scanner(System.in);

        System.out.println("Nombre del Pokemon: ");
        String NomPok=sc.nextLine();
        System.out.println("Tipo de pokemon: ");
        String TipPok=sc.nextLine();
        System.out.println("Vida del Pokemon: ");
        int VidaPok=sc.nextInt();
        System.out.println("Ataque del Pokemon: ");
        int AtaquePok=sc.nextInt();

        try{
            String sql = "INSERT INTO pokemones (Nombre, Tipo, Vida, Ataque) VALUES (?, ?, ?, ?)";
            PreparedStatement insert = cx.prepareStatement(sql);
            insert.setString(1, NomPok);
            insert.setString(2, TipPok);
            insert.setInt(3, VidaPok);
            insert.setInt(4, AtaquePok);
            insert.executeUpdate();
            System.out.println("Pokemon registrado correctamente");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
