package Mochila;

import Pokedex_Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.util.Scanner;

public class InsertarBag {
    public static void main (String[] args) {
        Connection cx = Conexion.getConexion();
        Scanner sc = new Scanner(System.in);

        System.out.println("Nombre del objeto: ");
        String NomObj=sc.nextLine();
        System.out.println("Cantidad del objeto: ");
        int CantidadObj=sc.nextInt();

        try{
            String sql = "INSERT INTO bag (Tipo, Cantidad) VALUES (?, ?)";
            PreparedStatement insert = cx.prepareStatement(sql);
            insert.setString(1,NomObj);
            insert.setInt(2,CantidadObj);
            insert.executeUpdate();
            System.out.println("Objeto guardado correctamente");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
