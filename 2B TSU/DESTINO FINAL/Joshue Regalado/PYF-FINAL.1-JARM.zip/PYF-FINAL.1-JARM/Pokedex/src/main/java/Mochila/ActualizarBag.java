package Mochila;

import Pokedex_Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class ActualizarBag {

    public static void ActualizarBag() {

        Scanner sc = new Scanner(System.in);

        System.out.print("ID del objeto: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.println("Que deseas actualizar?");
        System.out.println("1. Tipo");
        System.out.println("2. Cantidad");

        int op = sc.nextInt();
        sc.nextLine();

        try {
            Connection cx = Conexion.getConexion();
            PreparedStatement ps;
            if (op == 1) {
                System.out.print("Nuevo tipo: ");
                String tipo = sc.nextLine();

                String sql = "UPDATE bag SET Tipo=? WHERE idbag=?";
                ps = cx.prepareStatement(sql);
                ps.setString(1, tipo);
                ps.setInt(2, id);
            } else if (op == 2) {
                System.out.print("Nueva cantidad: ");
                int cantidad = sc.nextInt();

                String sql = "UPDATE bag SET Cantidad=? WHERE idbag=?";
                ps = cx.prepareStatement(sql);
                ps.setInt(1, cantidad);
                ps.setInt(2, id);
            } else {
                System.out.println("Opcion invalida");
                return;
            }
            ps.executeUpdate();

            System.out.println("Mochila actualizada correctamente");

            ps.close();
            cx.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        ActualizarBag();
        LeerBag.LeerBag();
    }
}