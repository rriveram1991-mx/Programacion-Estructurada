package Mochila;

import Pokedex_Conexion.Conexion;

import java.sql.*;

public class LeerBag {
    public static void LeerBag(){
        Connection cx = Conexion.getConexion();
        try {
            Statement st = cx.createStatement();
            ResultSet rsCount = st.executeQuery("SELECT COUNT(*) AS total FROM bag");
            if(rsCount.next()){
                int total = rsCount.getInt("total");
                System.out.println("Total de objetos: "+total);
                System.out.println();
            }
            ResultSet rs = st.executeQuery("SELECT * FROM bag");
            System.out.println("INVENTARIO");
            System.out.println();
            while (rs.next()){
                System.out.println("# Objeto: "+rs.getInt("idbag"));
                System.out.println("Tipo del objeto: "+rs.getString("Tipo"));
                System.out.println("Cantidad: "+rs.getInt("Cantidad"));
                System.out.println();
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public static void main(String[] args) {
        LeerBag();
    }
}
