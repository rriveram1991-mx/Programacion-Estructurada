package MENU;

import Mochila.ActualizarBag;
import Mochila.EliminarBag;
import Mochila.InsertarBag;
import Mochila.LeerBag;

import Pokemones.InsertarPokemon;
import Pokemones.LeerPokemon;
import Pokemones.ActualizarPokemon;
import Pokemones.EliminarPokemon;

import java.util.Scanner;

public class Menu {

    public static void Menu() {

        Scanner sc = new Scanner(System.in);
        int op = 0;
        int op2 = 0;

        do {

            System.out.println("\n===== POKEDEX =====");
            System.out.println("1. Insertar");
            System.out.println("2. Leer");
            System.out.println("3. Actualizar");
            System.out.println("4. Eliminar");
            System.out.println("5. Salir");
            System.out.print("Opcion: ");

            op = sc.nextInt();

            switch (op) {

                case 1:
                    System.out.println("En 1.Pokemones o 2.Mochila");
                    op2=sc.nextInt();
                        if (op2 == 1) {
                            InsertarPokemon.main(null);
                        } else if (op2 == 2) {
                            InsertarBag.main(null);
                        } else {
                            System.out.println("Opcion invalida");
                        }
                    break;

                case 2:
                    System.out.println("En 1.Pokemones o 2.Mochila");
                    op2=sc.nextInt();
                        if (op2 == 1) {
                            LeerPokemon.main(null);
                        } else if (op2 == 2) {
                            LeerBag.main(null);
                        } else {
                            System.out.println("Opcion invalida");
                        }
                    break;

                case 3:
                    System.out.println("En 1.Pokemones o 2.Mochila");
                    op2=sc.nextInt();
                    if (op2 == 1) {
                        ActualizarPokemon.main(null);
                    } else if (op2 == 2) {
                        ActualizarBag.main(null);
                    } else {
                        System.out.println("Opcion invalida");
                    }
                    break;

                case 4:
                    System.out.println("En 1.Pokemones o 2.Mochila");
                    op2=sc.nextInt();
                    if (op2 == 1) {
                        EliminarPokemon.main(null);
                    } else if (op2 == 2) {
                        EliminarBag.main(null);
                    } else {
                        System.out.println("Opcion invalida");
                    }
                    break;

                case 5:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opcion invalida");
            }

        } while (op != 5);
    }

    public static void main(String[] args) {
        Menu();
    }
}