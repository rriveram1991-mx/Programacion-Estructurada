package Pokemones;

import Pokedex_Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class EliminarPokemon {

    public static void EliminarPokemon() {

        Scanner sc = new Scanner(System.in);

        System.out.print("ID del Pokemon a eliminar: ");
        int id = sc.nextInt();

        try {

            Connection cx = Conexion.getConexion();

            String sql = "DELETE FROM pokemones WHERE ID_Pokemon=?";

            PreparedStatement ps = cx.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

            System.out.println("Pokemon eliminado correctamente");

            ps.close();
            cx.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        EliminarPokemon();
        LeerPokemon.LeerPokemon();
    }
}