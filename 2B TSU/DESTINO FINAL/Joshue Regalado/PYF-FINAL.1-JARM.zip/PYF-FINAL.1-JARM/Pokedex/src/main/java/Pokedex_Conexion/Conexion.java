package Pokedex_Conexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    public static Connection getConexion() {
        Connection Conexion = null;

        String baseDatos = "pokedex";
        String url = "jdbc:mysql://localhost:3306/" + baseDatos;
        String usuario = "root";
        String pass = "123456789";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Conexion = DriverManager.getConnection(url, usuario, pass);

        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }

        return Conexion;
    }

    public static void main(String[] args) {

        Connection Conexion = getConexion();

        if (Conexion != null) {
            System.out.println("Conexion Exitosa");
        } else {
            System.out.println("Error en la conexión");
        }
    }
}
