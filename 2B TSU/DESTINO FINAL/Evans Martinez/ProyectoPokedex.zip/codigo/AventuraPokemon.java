package CRUD_2B;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class AventuraPokemon {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int opcion = 0;

        System.out.println("======================================");
        System.out.println("  ¡BIENVENIDO ENTRENADOR EVANS!       ");
        System.out.println("======================================");

        do {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Atrapar nuevo Pokémon (CREATE)");
            System.out.println("2. Ver mi Pokédex (READ)");
            System.out.println("3. Ver mi Mochila (READ)");
            System.out.println("4. Editar un Pokémon (UPDATE MANUAL) <-- NUEVO");
            System.out.println("5. Usar un Objeto (UPDATE AUTOMÁTICO)");
            System.out.println("6. Liberar Pokémon (DELETE)");
            System.out.println("7. Guardar y Salir");
            System.out.print("¿Qué deseas hacer?: ");

            try {
                // SOLUCIÓN AL BUG DEL TECLADO: Todo se lee como texto y se convierte a número
                opcion = Integer.parseInt(teclado.nextLine());

                Connection cnx = Conexion.getConnection();

                switch (opcion) {
                    case 1:
                        // --- CREATE ---
                        System.out.println("\n--- ATRAPAR POKÉMON ---");
                        System.out.print("Nombre del Pokémon: ");
                        String nombre = teclado.nextLine();
                        System.out.print("Tipo (Fuego, Agua, Planta...): ");
                        String tipo = teclado.nextLine();
                        System.out.print("Nivel: ");
                        int nivel = Integer.parseInt(teclado.nextLine());
                        System.out.print("Puntos de Salud (PS): ");
                        int ps = Integer.parseInt(teclado.nextLine());

                        String sqlInsert = "INSERT INTO pokemones (nombre, tipo, nivel, ps_maximos) VALUES (?, ?, ?, ?)";
                        PreparedStatement psInsert = cnx.prepareStatement(sqlInsert);
                        psInsert.setString(1, nombre);
                        psInsert.setString(2, tipo);
                        psInsert.setInt(3, nivel);
                        psInsert.setInt(4, ps);

                        psInsert.executeUpdate();
                        System.out.println("¡" + nombre + " fue registrado en la Pokédex!");
                        psInsert.close();
                        break;

                    case 2:
                        // --- READ POKÉDEX ---
                        System.out.println("\n--- TU POKÉDEX ---");
                        Statement stPokedex = cnx.createStatement();
                        ResultSet rsPokedex = stPokedex.executeQuery("SELECT * FROM pokemones");

                        while (rsPokedex.next()) {
                            System.out.println("ID: " + rsPokedex.getInt("id_pokemon") +
                                    " | Nombre: " + rsPokedex.getString("nombre") +
                                    " | Tipo: " + rsPokedex.getString("tipo") +
                                    " | Nivel: " + rsPokedex.getInt("nivel"));
                        }
                        stPokedex.close();
                        break;

                    case 3:
                        // --- READ MOCHILA ---
                        System.out.println("\n--- TU MOCHILA ---");
                        Statement stMochila = cnx.createStatement();
                        ResultSet rsMochila = stMochila.executeQuery("SELECT * FROM mochila");

                        while (rsMochila.next()) {
                            System.out.println("ID Item: " + rsMochila.getInt("id_item") +
                                    " | Objeto: " + rsMochila.getString("nombre_item") +
                                    " | Cantidad: " + rsMochila.getInt("cantidad"));
                        }
                        stMochila.close();
                        break;

                    case 4:
                        // --- UPDATE MANUAL (Igual al video del profe) ---
                        System.out.println("\n--- EDITAR POKÉMON ---");
                        System.out.print("Ingresa el ID del Pokémon que vas a editar: ");
                        int idEditar = Integer.parseInt(teclado.nextLine());

                        System.out.print("Nuevo Nombre: ");
                        String nuevoNombre = teclado.nextLine();
                        System.out.print("Nuevo Nivel: ");
                        int nuevoNivel = Integer.parseInt(teclado.nextLine());

                        // Actualizamos nombre y nivel basándonos en el ID
                        String sqlUpdateManual = "UPDATE pokemones SET nombre = ?, nivel = ? WHERE id_pokemon = ?";
                        PreparedStatement psUpdateManual = cnx.prepareStatement(sqlUpdateManual);
                        psUpdateManual.setString(1, nuevoNombre);
                        psUpdateManual.setInt(2, nuevoNivel);
                        psUpdateManual.setInt(3, idEditar);

                        int filasEditadas = psUpdateManual.executeUpdate();
                        if (filasEditadas > 0) {
                            System.out.println("¡Datos actualizados correctamente!");
                        } else {
                            System.out.println("No se encontró ningún Pokémon con ese ID.");
                        }
                        psUpdateManual.close();
                        break;

                    case 5:
                        // --- UPDATE AUTOMÁTICO (Restar objetos) ---
                        System.out.println("\n--- USAR OBJETO ---");
                        System.out.print("Ingresa el 'ID Item' del objeto a usar: ");
                        int idItem = Integer.parseInt(teclado.nextLine());

                        String sqlUpdate = "UPDATE mochila SET cantidad = cantidad - 1 WHERE id_item = ? AND cantidad > 0";
                        PreparedStatement psUpdate = cnx.prepareStatement(sqlUpdate);
                        psUpdate.setInt(1, idItem);

                        int filasCambiadas = psUpdate.executeUpdate();
                        if (filasCambiadas > 0) {
                            System.out.println("¡Objeto utilizado! Se ha restado 1 de tu mochila.");
                        } else {
                            System.out.println("Error: Te quedaste sin el objeto o el ID no existe.");
                        }
                        psUpdate.close();
                        break;

                    case 6:
                        // --- DELETE ---
                        System.out.println("\n--- LIBERAR POKÉMON ---");
                        System.out.print("Ingresa el 'ID' del Pokémon que quieres liberar: ");
                        int idLiberar = Integer.parseInt(teclado.nextLine());

                        String sqlDelete = "DELETE FROM pokemones WHERE id_pokemon = ?";
                        PreparedStatement psDelete = cnx.prepareStatement(sqlDelete);
                        psDelete.setInt(1, idLiberar);

                        int filasBorradas = psDelete.executeUpdate();
                        if (filasBorradas > 0) {
                            System.out.println("El Pokémon fue liberado con éxito.");
                        } else {
                            System.out.println("No se encontró ningún Pokémon con ese ID.");
                        }
                        psDelete.close();
                        break;

                    case 7:
                        System.out.println("Guardando partida... ¡Adiós Entrenador!");
                        break;

                    default:
                        System.out.println("Opción no válida. Intenta de nuevo.");
                }

                if(cnx != null) cnx.close();

            } catch (NumberFormatException e) {
                System.out.println("¡Cuidado! Debes ingresar un número válido, no letras.");
            } catch (Exception e) {
                System.out.println("Error general en el sistema: " + e.getMessage());
            }

        } while (opcion != 7);

        teclado.close();
    }
}