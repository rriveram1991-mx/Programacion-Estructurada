package CRUD_2B.modelo;

public class Postre {
    private int idPostres;
    private int idCategoria;
    private String nombre;
    private int precio;
    private int cantidadPorciones;


    public Postre() {}


    public Postre(int idPostres, int idCategoria, String nombre,
                  int precio, int cantidadPorciones) {
        this.idPostres = idPostres;
        this.idCategoria = idCategoria;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidadPorciones = cantidadPorciones;
    }


    public int getIdPostres() { return idPostres; }
    public void setIdPostres(int idPostres) { this.idPostres = idPostres; }
    public int getIdCategoria() { return idCategoria; }
    public void setIdCategoria(int idCategoria) { this.idCategoria = idCategoria; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getPrecio() { return precio; }
    public void setPrecio(int precio) { this.precio = precio; }
    public int getCantidadPorciones() { return cantidadPorciones; }
    public void setCantidadPorciones(int cantidadPorciones) { this.cantidadPorciones = cantidadPorciones; }
}
