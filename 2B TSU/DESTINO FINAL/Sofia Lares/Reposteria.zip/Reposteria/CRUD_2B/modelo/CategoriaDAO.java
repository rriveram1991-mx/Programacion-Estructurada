package CRUD_2B.dao;

import CRUD_2B.Conexion;
import CRUD_2B.modelo.Categoria;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    // CREATE
    public void insertar(Categoria c) {
        String sql = "INSERT INTO categoria (nombre_categoria, tecnica_principal, nivel_dificultad, refrigeracion) VALUES (?,?,?,?)";
        try (Connection cnx = Conexion.getConnection();
             PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setString(1, c.getNombreCategoria());
            ps.setString(2, c.getTecnicaPrincipal());
            ps.setInt(3, c.getNivelDificultad());
            ps.setString(4, c.getRefrigeracion());
            ps.executeUpdate();
            System.out.println("Categoría insertada.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // READ - todos
    public List<Categoria> obtenerTodos() {
        List<Categoria> lista = new ArrayList<>();
        String sql = "SELECT * FROM categoria";
        try (Connection cnx = Conexion.getConnection();
             Statement st = cnx.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Categoria c = new Categoria(
                        rs.getInt("id_categoria"),
                        rs.getString("nombre_categoria"),
                        rs.getString("tecnica_principal"),
                        rs.getInt("nivel_dificultad"),
                        rs.getString("refrigeracion")
                );
                lista.add(c);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return lista;
    }

    // UPDATE
    public void actualizar(Categoria c) {
        String sql = "UPDATE categoria SET nombre_categoria=?, tecnica_principal=?, nivel_dificultad=?, refrigeracion=? WHERE id_categoria=?";
        try (Connection cnx = Conexion.getConnection();
             PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setString(1, c.getNombreCategoria());
            ps.setString(2, c.getTecnicaPrincipal());
            ps.setInt(3, c.getNivelDificultad());
            ps.setString(4, c.getRefrigeracion());
            ps.setInt(5, c.getIdCategoria());
            ps.executeUpdate();
            System.out.println("Categoría actualizada.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // DELETE
    public void eliminar(int id) {
        String sql = "DELETE FROM categoria WHERE id_categoria=?";
        try (Connection cnx = Conexion.getConnection();
             PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Categoría eliminada.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}