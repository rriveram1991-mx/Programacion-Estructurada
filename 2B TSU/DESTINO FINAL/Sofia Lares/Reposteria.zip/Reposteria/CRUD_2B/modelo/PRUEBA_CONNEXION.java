package CRUD_2B;

import java.sql.Connection;

public class PRUEBA_CONNEXION
{
    public static void main(String[] args)
    {
        Connection prueba = Conexion.getConnection();

        if (prueba != null) {
            System.out.println("¡Éxito! Conexion a Reposteria");
        } else {
            System.out.println("Algo falló, revisa tu contraseña o si MySQL está encendido.");
        }
    }
}