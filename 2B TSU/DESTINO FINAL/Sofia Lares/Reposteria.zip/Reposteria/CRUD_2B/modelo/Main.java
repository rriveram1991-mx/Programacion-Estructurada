package org.example;

import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Connection miConexion = Conexion.conectar();
        Scanner teclado = new Scanner(System.in);

        if (miConexion != null) {
            System.out.println("--- SISTEMA DE REPOSTERÍA VINCULADO ---");
            int opcion = 0;

            while (opcion != 5) {
                System.out.println("\n--- MENÚ PRINCIPAL ---");
                System.out.println("1. Registrar Postre (Insert)");
                System.out.println("2. Ver Catálogo (Read)");
                System.out.println("3. Actualizar Datos (Update)");
                System.out.println("4. Eliminar Postre (Delete)");
                System.out.println("5. Salir");
                System.out.print("Selecciona una opción: ");
                opcion = teclado.nextInt();
                teclado.nextLine(); // Limpiar el buffer del Scanner

                switch (opcion) {
                    case 1: insertarPostre(miConexion, teclado); break;
                    case 2: leerPostres(miConexion); break;
                    case 3: actualizarPostre(miConexion, teclado); break;
                    case 4: eliminarPostre(miConexion, teclado); break;
                    case 5: System.out.println("Saliendo..."); break;
                }
            }
            try { miConexion.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    // --- MÉTODO INSERTAR (Sincronizado con tu DB) ---
    public static void insertarPostre(Connection con, Scanner sc)
    {

        System.out.print("Nombre del postre: ");
        String nom = sc.nextLine();
        System.out.print("Precio: ");
        int pre = sc.nextInt();
        sc.nextLine();
        System.out.print("Cantidad de Porciones (ej: '12 porciones'): ");
        int por = sc.nextInt();

        String sql = "INSERT INTO postres ( nombre, precio, cantidad_porciones) VALUES (?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nom);
            ps.setInt(2, pre);
            ps.setInt(3, por);
            ps.executeUpdate();
            System.out.println("¡Postre guardado con éxito en la base de datos!");
        } catch (SQLException e)
        {
            System.out.println("Error al insertar: " + e.getMessage());
        }
    }

    // --- MÉTODO LEER ---
    public static void leerPostres(Connection con)
    {
        String sql = "SELECT * FROM postres";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql))
        {
            System.out.println("\n--- CATÁLOGO DE POSTRES ---");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id_postres") +
                        " | Cat: " + rs.getInt("id_categoria") +
                        " | Nom: " + rs.getString("nombre") +
                        " | $" + rs.getDouble("precio") +
                        " | Porciones: " + rs.getString("cantidad_porciones"));
            }
        } catch (SQLException e) { System.out.println("Error al leer: " + e.getMessage()); }
    }

    // --- MÉTODO ACTUALIZAR ---
    public static void actualizarPostre(Connection con, Scanner sc) {
        System.out.print("ID del postre a modificar: ");
        int id = sc.nextInt();
        System.out.print("Nuevo Precio: ");
        double nPre = sc.nextDouble();
        sc.nextLine();
        System.out.print("Nuevas Porciones: ");
        String nPor = sc.nextLine();

        String sql = "UPDATE postres SET precio = ?, cantidad_porciones = ? WHERE id_postres = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, nPre);
            ps.setString(2, nPor);
            ps.setInt(3, id);
            ps.executeUpdate();
            System.out.println("Postre actualizado correctamente.");
        } catch (SQLException e) { System.out.println("Error al actualizar: " + e.getMessage()); }
    }

    // --- MÉTODO ELIMINAR ---
    public static void eliminarPostre(Connection con, Scanner sc) {
        System.out.print("ID del postre a eliminar: ");
        int id = sc.nextInt();
        String sql = "DELETE FROM postres WHERE id_postres = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Postre borrado de la base de datos.");
        } catch (SQLException e) { System.out.println("Error al eliminar: " + e.getMessage()); }
    }
}