package CRUD_2B.modelo;

public class Categoria {
    private int idCategoria;
    private String nombreCategoria;
    private String tecnicaPrincipal;
    private int nivelDificultad;
    private String refrigeracion;


    public Categoria() {}


    public Categoria(int idCategoria, String nombreCategoria,
                     String tecnicaPrincipal, int nivelDificultad, String refrigeracion) {
        this.idCategoria = idCategoria;
        this.nombreCategoria = nombreCategoria;
        this.tecnicaPrincipal = tecnicaPrincipal;
        this.nivelDificultad = nivelDificultad;
        this.refrigeracion = refrigeracion;
    }


    public int getIdCategoria() { return idCategoria; }
    public void setIdCategoria(int idCategoria) { this.idCategoria = idCategoria; }
    public String getNombreCategoria() { return nombreCategoria; }
    public void setNombreCategoria(String nombreCategoria) { this.nombreCategoria = nombreCategoria; }
    public String getTecnicaPrincipal() { return tecnicaPrincipal; }
    public void setTecnicaPrincipal(String tecnicaPrincipal) { this.tecnicaPrincipal = tecnicaPrincipal; }
    public int getNivelDificultad() { return nivelDificultad; }
    public void setNivelDificultad(int nivelDificultad) { this.nivelDificultad = nivelDificultad; }
    public String getRefrigeracion() { return refrigeracion; }
    public void setRefrigeracion(String refrigeracion) { this.refrigeracion = refrigeracion; }
}