package CRUD_2B.dao;

import CRUD_2B.Conexion;
import CRUD_2B.modelo.Postre;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PostreDAO {

    // CREATE
    public void insertar(Postre p) {
        String sql = "INSERT INTO postres (id_categoria, nombre, precio, cantidad_porciones) VALUES (?,?,?,?)";
        try (Connection cnx = Conexion.getConnection();
             PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, p.getIdCategoria());
            ps.setString(2, p.getNombre());
            ps.setInt(3, p.getPrecio());
            ps.setInt(4, p.getCantidadPorciones());
            ps.executeUpdate();
            System.out.println("Postre insertado.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // READ
    public List<Postre> obtenerTodos() {
        List<Postre> lista = new ArrayList<>();
        String sql = "SELECT * FROM postres";
        try (Connection cnx = Conexion.getConnection();
             Statement st = cnx.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Postre p = new Postre(
                        rs.getInt("id_postres"),
                        rs.getInt("id_categoria"),
                        rs.getString("nombre"),
                        rs.getInt("precio"),
                        rs.getInt("cantidad_porciones")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return lista;
    }

    // READ - por id
    public Postre obtenerPorId(int id) {
        Postre p = null;
        String sql = "SELECT * FROM postres WHERE id_postres=?";
        try (Connection cnx = Conexion.getConnection();
             PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                p = new Postre(
                        rs.getInt("id_postres"),
                        rs.getInt("id_categoria"),
                        rs.getString("nombre"),
                        rs.getInt("precio"),
                        rs.getInt("cantidad_porciones")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return p;
    }

    // UPDATE
    public void actualizar(Postre p) {
        String sql = "UPDATE postres SET id_categoria=?, nombre=?, precio=?, cantidad_porciones=? WHERE id_postres=?";
        try (Connection cnx = Conexion.getConnection();
             PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, p.getIdCategoria());
            ps.setString(2, p.getNombre());
            ps.setInt(3, p.getPrecio());
            ps.setInt(4, p.getCantidadPorciones());
            ps.setInt(5, p.getIdPostres());
            ps.executeUpdate();
            System.out.println("Postre actualizado.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // DELETE
    public void eliminar(int id) {
        String sql = "DELETE FROM postres WHERE id_postres=?";
        try (Connection cnx = Conexion.getConnection();
             PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Postre eliminado.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // DELETE por categoría
    public void eliminarPorCategoria(int idCategoria) {
        String sql = "DELETE FROM postres WHERE id_categoria=?";
        try (Connection cnx = Conexion.getConnection();
             PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idCategoria);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

}