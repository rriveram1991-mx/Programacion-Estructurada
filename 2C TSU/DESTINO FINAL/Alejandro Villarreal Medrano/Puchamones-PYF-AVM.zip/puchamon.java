package org.example;

import java.sql.*;
import java.util.Scanner;

public class puchamon {

    static Connection con;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        conectar();

        int op;

        do {
            System.out.println("\n===== MENU =====");
            System.out.println("1. Registrar Pokemon");
            System.out.println("2. Actualizar Pokemon/Mochila");
            System.out.println("3. Eliminar Pokemon");
            System.out.println("4. Vaciar todo");
            System.out.println("5. Mostrar mochila");
            System.out.println("6. Mostrar pokemones"); // 🔥 NUEVO
            System.out.println("0. Salir");

            op = sc.nextInt();

            switch (op) {
                case 1 -> registrarPokemon();
                case 2 -> actualizar();
                case 3 -> eliminarPokemon();
                case 4 -> vaciarTodo();
                case 5 -> mostrarMochila();
                case 6 -> mostrarPokemones(); // 🔥 NUEVO
            }

        } while (op != 0);
    }

    public static void conectar() {
        try {
            String url = "jdbc:mysql://localhost:3306/pokemon_game?useSSL=false&serverTimezone=UTC";
            String user = "root";
            String password = "0022";

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, user, password);

            System.out.println("Conectado a MySQL");

        } catch (Exception e) {
            System.out.println("Error de conexión");
            e.printStackTrace();
        }
    }

    public static void registrarPokemon() {
        try {
            System.out.print("Nombre: ");
            String nombre = sc.next();

            System.out.print("Tipo: ");
            String tipo = sc.next();

            System.out.print("Salud: ");
            sc.nextInt(); // ignorado (no está en BD)

            System.out.print("Ataque: ");
            sc.nextInt(); // ignorado

            System.out.print("Defensa: ");
            sc.nextInt(); // ignorado

            String sql = "INSERT INTO pokemones (Nombre, Tipo) VALUES (?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nombre);
            ps.setString(2, tipo);

            ps.executeUpdate();

            System.out.println("Pokemon registrado");

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            String sql = "INSERT INTO mochila (Nombre, cantidad) VALUES (?,?)";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "Pocion");
            ps.setInt(2, 1);

            ps.executeUpdate();

            System.out.println("Se agregó una poción a la mochila");

        } catch (Exception e) {
            e.printStackTrace();
        }

        mostrarMochila();
    }

    public static void actualizar() {
        try {
            System.out.println("1. Pokemon  2. Mochila");
            int op = sc.nextInt();

            if (op == 1) {
                System.out.print("ID Pokemon: ");
                int id = sc.nextInt();

                System.out.print("Nuevo nombre: ");
                String nombre = sc.next();

                System.out.print("Nuevo tipo: ");
                String tipo = sc.next();

                String sql = "UPDATE pokemones SET Nombre=?, Tipo=? WHERE idpokemones=?";
                PreparedStatement ps = con.prepareStatement(sql);

                ps.setString(1, nombre);
                ps.setString(2, tipo);
                ps.setInt(3, id);

                ps.executeUpdate();

            } else {
                System.out.print("Nueva cantidad de pociones: ");
                int cant = sc.nextInt();

                String sql = "UPDATE mochila SET cantidad=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, cant);
                ps.executeUpdate();
            }

            System.out.println("Actualizado");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void eliminarPokemon() {
        try {
            System.out.print("ID a eliminar: ");
            int id = sc.nextInt();

            String sql = "DELETE FROM pokemones WHERE idpokemones=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("Pokemon eliminado");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void mostrarMochila() {
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM mochila");

            System.out.println("\n--- MOCHILA ---");
            while (rs.next()) {
                System.out.println(
                        rs.getInt("idmochila") + " " +
                                rs.getString("Nombre") + " " +
                                rs.getInt("cantidad")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 🔥 NUEVO MÉTODO
    public static void mostrarPokemones() {
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM pokemones");

            System.out.println("\n--- LISTA DE POKEMONES ---");
            while (rs.next()) {
                System.out.println(
                        rs.getInt("idpokemones") + " " +
                                rs.getString("Nombre") + " " +
                                rs.getString("Tipo")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void vaciarTodo() {
        try {
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM mochila");

            System.out.println("Objetos en mochila:");
            while (rs.next()) {
                System.out.println(rs.getString("Nombre") + " - " + rs.getInt("cantidad"));
            }

            st.executeUpdate("DELETE FROM pokemones");
            st.executeUpdate("DELETE FROM mochila");

            System.out.println("Todo eliminado");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}