package pokedex.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;

public class conexion {


    public static Connection getConnection() {
        Connection conexion = null;
        var BaseDatos = "pokemon_data";
        var urlmysql = "jdbc:mysql://localhost:3306/" + BaseDatos;
        var usrmysql = "root";
        var passmysql = "toor";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(urlmysql, usrmysql, passmysql);
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("No se pudo conectar con Mysql: " + e.getMessage());
        }
        return conexion;
    }


    public static void insertarPokemon(Connection conn, String nombre, String tipo, int salud, int ataque) {
        String sql = "INSERT INTO infoooo (nombre, Tipo, Salud, Ataque) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, tipo);
            stmt.setInt(3, salud);
            stmt.setInt(4, ataque);

            int filas = stmt.executeUpdate();
            System.out.println("Pokémon registrado. Filas afectadas: " + filas);
        } catch (SQLException e) {
            System.out.println("Error al insertar Pokémon: " + e.getMessage());
        }
    }


    public static void leerInfo(Connection conn) {
        String sql = "SELECT idpoke, nombre, Tipo, Salud, Ataque FROM infoooo";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("=== Tabla infoooo ===");
            while (rs.next()) {
                int id = rs.getInt("idpoke");
                String nombre = rs.getString("nombre");
                String tipo = rs.getString("Tipo");
                int salud = rs.getInt("Salud");
                int ataque = rs.getInt("Ataque");

                System.out.println(id + " | " + nombre + " | " + tipo +
                        " | Salud: " + salud + " | Ataque: " + ataque);
            }
        } catch (SQLException e) {
            System.out.println("Error al leer infoooo: " + e.getMessage());
        }
    }


    public static void leerMochila(Connection conn) {
        String sql = "SELECT id_pocion, Nombre, funcion, Cantidad, Descripcion FROM mochila";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("=== Tabla mochila ===");
            while (rs.next()) {
                int id = rs.getInt("id_pocion");
                String nombre = rs.getString("Nombre");
                String funcion = rs.getString("funcion");
                int cantidad = rs.getInt("Cantidad");
                String descripcion = rs.getString("Descripcion");

                System.out.println(id + " | " + nombre + " | Función: " + funcion +
                        " | Cantidad: " + cantidad + " | Descripción: " + descripcion);
            }
        } catch (SQLException e) {
            System.out.println("Error al leer mochila: " + e.getMessage());
        }
    }
    public static void eliminarPokemonPorId(Connection conn, int idpoke) {
        String sql = "DELETE FROM infoooo WHERE idpoke = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idpoke);
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Pokémon con id " + idpoke + " eliminado correctamente.");
            } else {
                System.out.println("No se encontró Pokémon con id " + idpoke);
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar Pokémon: " + e.getMessage());
        }
    }


    public static void main(String[] args) {
        try (Connection conn = getConnection()) {
            if (conn != null) {
                System.out.println("Conexión lograda!");

                // Insertar Pokémon de prueba
                insertarPokemon(conn, "Bulbasaur", "Planta", 100, 49);
                insertarPokemon(conn, "Squirtle", "Agua", 95, 48);
                insertarPokemon(conn, "Charmander", "Fuego", 90, 52);

                // Leer datos de las tablas
                leerInfo(conn);
                leerMochila(conn);
            } else {
                System.out.println("Conexión fallida");
            }
        } catch (SQLException e) {
            System.out.println("Error en la conexión: " + e.getMessage());
        }
    }
}