package dao;

import Conexion.Conexion;
import model.Bag;

import java.sql.*;
import java.util.ArrayList;

public class BagDAO {

    public static ArrayList<Bag> listar() {
        ArrayList<Bag> lista = new ArrayList<>();

        try (Connection con = Conexion.getConnection()) {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM bag");

            while (rs.next()) {
                Bag b = new Bag(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getInt("cantidad")
                );
                lista.add(b);
            }

        } catch (Exception e) {
            System.out.println("Error al listar bag: " + e.getMessage());
        }

        return lista;
    }

    public static void actualizar(int id, int cantidad) {
        try (Connection con = Conexion.getConnection()) {

            String sql = "UPDATE bag SET cantidad=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, cantidad);
            ps.setInt(2, id);

            ps.executeUpdate();

            System.out.println("Bag actualizado correctamente");

        } catch (Exception e) {
            System.out.println("Error al actualizar bag: " + e.getMessage());
        }
    }
}