package CRUD;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertarPokemon {

    public static void InsertarPokemon() {

        try {
            Connection conx = Conexion.getConnection();

            String sql = "INSERT INTO pokemon (nombre, tipo) VALUES (?, ?)";
            PreparedStatement ps = conx.prepareStatement(sql);

            ps.setString(1, "Pikachu");
            ps.setString(2, "Electrico");

            ps.executeUpdate();

            System.out.println("Pokemon insertado");

            conx.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        InsertarPokemon();
    }
}