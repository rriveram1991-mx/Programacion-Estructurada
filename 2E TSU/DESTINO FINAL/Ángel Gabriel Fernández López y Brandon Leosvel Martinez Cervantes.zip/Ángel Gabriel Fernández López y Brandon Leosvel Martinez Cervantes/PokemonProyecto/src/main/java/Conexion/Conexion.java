package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    public static Connection getConnection() {

        Connection cxn = null;
        String basedatos = "pokedex_db";
        String url = "jdbc:mysql://localhost:3306/" + basedatos;
        String mysqluser = "root";
        String mysqlpwd = "Noticias1001.";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cxn = DriverManager.getConnection(url, mysqluser, mysqlpwd);
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }

        return cxn;
    }

    public static void main(String[] args) {
        Connection cxn = Conexion.getConnection();

        if (cxn != null)
            System.out.println("Conexion exitosa");
        else
            System.out.println("Error de conexion");
    }
}