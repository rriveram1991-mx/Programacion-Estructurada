package CRUD;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class ActualizarPokemon {

    public static void ActualizarPokemon() {

        try {
            Connection conx = Conexion.getConnection();

            String sql = "UPDATE pokemon SET nombre=?, tipo=? WHERE id=?";
            PreparedStatement ps = conx.prepareStatement(sql);

            ps.setString(1, "Raichu");
            ps.setString(2, "Electrico");
            ps.setInt(3, 1);

            ps.executeUpdate();

            System.out.println("Pokemon actualizado");

            conx.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        ActualizarPokemon();
    }
}