package org.example;

import dao.BagDAO;
import dao.PokemonDAO;
import model.Bag;
import model.Pokemon;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int op;

        do {
            System.out.println("\n===== POKEDEX PRO =====");
            System.out.println("1. Registrar Pokémon");
            System.out.println("2. Actualizar");
            System.out.println("3. Eliminar Pokémon");
            System.out.println("4. Buscar");
            System.out.println("0. Salir");

            System.out.print("Opción: ");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {

                case 1:
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();

                    System.out.print("Tipo: ");
                    String tipo = sc.nextLine();

                    PokemonDAO.insertar(nombre, tipo);
                    break;

                case 2:
                    System.out.println("1. Pokémon");
                    System.out.println("2. Bag");
                    System.out.print("Opción: ");
                    int opc = sc.nextInt();
                    sc.nextLine();

                    if (opc == 1) {

                        for (Pokemon p : PokemonDAO.listar()) {
                            System.out.println(p.getId() + " - " + p.getNombre() + " - " + p.getTipo());
                        }

                        System.out.print("ID: ");
                        int id = sc.nextInt();
                        sc.nextLine();

                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = sc.nextLine();

                        System.out.print("Nuevo tipo: ");
                        String nuevoTipo = sc.nextLine();

                        PokemonDAO.actualizar(id, nuevoNombre, nuevoTipo);

                    } else {

                        for (Bag b : BagDAO.listar()) {
                            System.out.println(b.getId() + " - " + b.getNombre() + " Cantidad: " + b.getCantidad());
                        }

                        System.out.print("ID: ");
                        int id = sc.nextInt();

                        System.out.print("Nueva cantidad: ");
                        int cant = sc.nextInt();

                        BagDAO.actualizar(id, cant);
                    }
                    break;

                case 3:

                    for (Pokemon p : PokemonDAO.listar()) {
                        System.out.println(p.getId() + " - " + p.getNombre());
                    }

                    System.out.print("ID a eliminar: ");
                    int idEliminar = sc.nextInt();

                    PokemonDAO.eliminar(idEliminar);
                    break;

                case 4:

                    System.out.println("1. Pokémon");
                    System.out.println("2. Bag");
                    System.out.print("Opción: ");
                    int opBuscar = sc.nextInt();

                    if (opBuscar == 1) {

                        for (Pokemon p : PokemonDAO.listar()) {
                            System.out.println(p.getId() + " - " + p.getNombre() + " - " + p.getTipo());
                        }

                    } else {

                        for (Bag b : BagDAO.listar()) {
                            System.out.println(b.getId() + " - " + b.getNombre() + " Cantidad: " + b.getCantidad());
                        }
                    }
                    break;
            }

        } while (op != 0);

        System.out.println("Sistema cerrado.");
    }
}
