package CRUD;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class BuscarPokemon {

    public static void BuscarPokemon() {

        try {
            Connection conx = Conexion.getConnection();

            Statement st = conx.createStatement();

            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS total FROM pokemon");
            if (rs.next()) {
                System.out.println("Total de pokemones: " + rs.getInt("total"));
                System.out.println();
            }

            ResultSet info = st.executeQuery("SELECT * FROM pokemon");

            while (info.next()) {
                System.out.println("ID: " + info.getInt("id"));
                System.out.println("Nombre: " + info.getString("nombre"));
                System.out.println("Tipo: " + info.getString("tipo"));
                System.out.println();
            }

            conx.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        BuscarPokemon();
    }
}