package CRUD;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class EliminarPokemon {

    public static void EliminarPokemon() {

        try {
            Connection conx = Conexion.getConnection();

            Statement st = conx.createStatement();

            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS total FROM pokemon");
            if (rs.next()) {
                System.out.println("Antes de eliminar: " + rs.getInt("total"));
                System.out.println();
            }

            String sql = "DELETE FROM pokemon WHERE id=?";
            PreparedStatement ps = conx.prepareStatement(sql);

            ps.setInt(1, 1);
            ps.executeUpdate();

            System.out.println("Pokemon eliminado");

            ResultSet rs2 = st.executeQuery("SELECT COUNT(*) AS total FROM pokemon");
            if (rs2.next()) {
                System.out.println("Despues de eliminar: " + rs2.getInt("total"));
            }

            conx.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        EliminarPokemon();
    }
}