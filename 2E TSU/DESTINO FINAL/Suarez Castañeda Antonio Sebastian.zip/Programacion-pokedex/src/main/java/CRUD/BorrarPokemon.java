package CRUD;

import pokedex.conexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class BorrarPokemon {
    public static void borrar() {
        Scanner sc = new Scanner(System.in);
        try {
            Connection cnx = conexion.getConnection();
            System.out.println("\n¿Que deseas borrar?");
            System.out.println("1. Pokemon");
            System.out.println("2. Objeto del inventario");
            System.out.print("Opcion: ");
            String opcion = sc.nextLine();

            if (opcion.equals("1")) {
                borrarPokemon(cnx, sc);
            } else if (opcion.equals("2")) {
                borrarInventario(cnx, sc);
            } else {
                System.out.println("Opcion no valida");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void borrarPokemon(Connection cnx, Scanner sc) {
        try {
            String sqlLista = "SELECT * FROM pokedex";
            PreparedStatement psLista = cnx.prepareStatement(sqlLista);
            ResultSet rs = psLista.executeQuery();
            System.out.println("\n--- Pokemones almacenados ---");
            System.out.println("ID   NOMBRE   TIPO");
            while (rs.next()) {
                System.out.println(rs.getInt("IDPOKEDEX") + "   " + rs.getString("NOMBRE") + "   " + rs.getString("TIPO"));
            }

            System.out.print("\nID del Pokemon a borrar: ");
            int id = Integer.parseInt(sc.nextLine());
            String sql = "DELETE FROM pokedex WHERE IDPOKEDEX=?";
            PreparedStatement ps = cnx.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Pokemon eliminado correctamente");
            System.out.println();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void borrarInventario(Connection cnx, Scanner sc) {
        try {
            String sqlLista = "SELECT * FROM inventario";
            PreparedStatement psLista = cnx.prepareStatement(sqlLista);
            ResultSet rs = psLista.executeQuery();
            System.out.println("\n--- Objetos en inventario ---");
            System.out.println("ID   NOMBRE   CANTIDAD");

            while (rs.next()) {
                System.out.println(rs.getInt("IDINV") + "   " + rs.getString("NOMBRE") + "   " + rs.getInt("CANTIDAD"));
            }

            System.out.print("\nID del objeto a borrar: ");
            int id = Integer.parseInt(sc.nextLine());
            String sql = "DELETE FROM inventario WHERE IDINV=?";
            PreparedStatement ps = cnx.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Objeto eliminado correctamente");
            System.out.println();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}