package CRUD;

import pokedex.conexion.conexion;

import java.net.ConnectException;
import java.sql.*;
import java.util.Scanner;

public class UpdatePokemon {
    public static void actualizar(){
        Scanner sc = new Scanner(System.in);
        System.out.println("\nQue desea actualizar?");
        try{
            Connection con = conexion.getConnection();

            System.out.println("\nQue desea actualizar?");
            System.out.println("1. Pokedex");
            System.out.println("2. Inventario/Mochila");
            System.out.println("Opcion: "); String opcion = sc.nextLine();
            if(opcion.equals("1")){
                actualizarPokedex(con, sc);
            } else if (opcion.equals("2")) {
                actualizarInventario(con, sc);
            } else  {
                System.out.println("Opcion incorrecta");
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public static void actualizarPokedex(Connection con, Scanner sc){
        try{
            String sqlLista = "SELECT * FROM pokedex";
            PreparedStatement psLista = con.prepareStatement(sqlLista);
            ResultSet rs = psLista.executeQuery();
            System.out.println("\n--- Pokedex actual ---");

            while (rs.next()) {
                System.out.println("[" + rs.getInt("IDPOKEDEX") + "] " + rs.getString("NOMBRE") + " - " + rs.getString("TIPO"));
            }

            System.out.print("\nID del Pokemon a actualizar: ");
            int ID = Integer.parseInt(sc.nextLine());
            System.out.print("Nuevo nombre: ");
            String pokemon = sc.nextLine();
            System.out.print("Nuevo tipo: ");
            String tipop = sc.nextLine();

            String sql = "UPDATE pokedex SET NOMBRE=?, TIPO=? WHERE IDPOKEDEX=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, pokemon);
            ps.setString(2, tipop);
            ps.setInt(3, ID);
            ps.executeUpdate();

            System.out.println("La Pokedex se ha actualizado correctamente");
            System.out.println();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    public static void actualizarInventario(Connection con, Scanner sc){
        try{
            String sqlLista = "SELECT * FROM inventario";
            PreparedStatement psLista = con.prepareStatement(sqlLista);
            ResultSet rs = psLista.executeQuery();
            System.out.println("\n--- Inventario actual ---");

            while (rs.next()) {
                System.out.println("[" + rs.getInt("IDINV") + "] " + rs.getString("NOMBRE") + " - Cantidad: " + rs.getInt("CANTIDAD")
                );
            }

            System.out.print("\nID del Objeto a actualizar: ");
            int id = Integer.parseInt(sc.nextLine());
            System.out.print("Nueva cantidad: ");
            int cantidad = Integer.parseInt(sc.nextLine());

            String sql = "UPDATE inventario SET CANTIDAD=? WHERE IDINV=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, cantidad);
            ps.setInt(2, id);
            ps.executeUpdate();

            System.out.println("El inventario se ha actualizado correctamente");
            System.out.println();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

}
