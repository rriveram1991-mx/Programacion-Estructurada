package CRUD;

import pokedex.conexion.conexion;

import javax.swing.plaf.nimbus.State;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class BuscarPokemon {
    public static void buscarPokemon(){
        Connection cnx = conexion.getConnection();
        try{
            Statement st = cnx.createStatement();
            ResultSet clCount = st.executeQuery("SELECT COUNT(*) as total FROM pokedex");
            if (clCount.next()){
                int total = clCount.getInt("total");
                System.out.println("Total de pokemones: " + total);
                System.out.println();
            }

            ResultSet info = st.executeQuery("SELECT * FROM pokedex");
            System.out.println("Pokemones añadidos en la pokedex");
            System.out.println();
            while (info.next()){
                System.out.println("ID del pokemon: " + info.getInt("IDPOKEDEX"));
                System.out.println("Nombre del pokemon: " + info.getString("NOMBRE"));
                System.out.println("Tipo del pokemon: " + info.getString("TIPO"));
                System.out.println();
            }
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public static void main(String[] args) {
        buscarPokemon();
    }
}
