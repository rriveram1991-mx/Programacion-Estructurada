package CRUD;

import pokedex.conexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertarPokemon {

    public static void insertarPokemon(String pokemon, String tipo){
        Connection cxm = conexion.getConnection();
        try{
            String sql = "INSERT INTO pokedex (NOMBRE, TIPO) VALUES (?, ?)";
            PreparedStatement insert = cxm.prepareStatement(sql);
            insert.setString(1, pokemon);
            insert.setString(2, tipo);
            insert.executeUpdate();
            System.out.println("Pokemon registrado exitosamente");
        } catch ( Exception e){
            System.out.println(e.getMessage());
        }

        if (cxm == null){
            System.out.println("Imposible conectar con la pokedex");
            return;
        }
    }
    public static void main (String[] args){
     InsertarPokemon.insertarPokemon("Greninja","Agua");
    }
}
