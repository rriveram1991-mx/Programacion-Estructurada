package pokedex.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexion {

    public static Connection getConnection(){
        Connection cxm = null;
        var basedatos = "pokedex.invent";
        var url = "jdbc:mysql://localhost:3306/" + basedatos + "?useSSL=false&serverTimezone=UTC";
        var mysqlusr = "root";
        var mysqlowd = "toor";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            cxm = DriverManager.getConnection(url, mysqlusr, mysqlowd);
        }catch (ClassNotFoundException | SQLException e){
            System.out.println("Error al conectar: " + e.getMessage());
        }
        return cxm;
    }

    public static void main(String[] args){
        var cxn = conexion.getConnection();
        if(cxn != null){
            System.out.println("Conexion Exitosa con MySQL: "+ cxn);
        } else {
            System.out.println("Conexion no Exitosa");
        }
    }
}
