package MENU;

import CRUD.BuscarPokemon;
import CRUD.InsertarPokemon;
import CRUD.UpdatePokemon;
import CRUD.BorrarPokemon;

import java.util.Scanner;

public class MenuPrincipal {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n==============================");
            System.out.println("        SISTEMA POKEDEX");
            System.out.println("==============================");
            System.out.println(" 1. Registrar Pokemon");
            System.out.println(" 2. Buscar Pokemones");
            System.out.println(" 3. Actualizar Pokemon / Inventario");
            System.out.println(" 4. Borrar Pokemon / Objeto");
            System.out.println(" 5. Salir");
            System.out.println("==============================");
            System.out.print("Elige una opcion: ");

            String opcion = sc.nextLine();

            switch (opcion) {

                // INSERTAR
                case "1":
                    System.out.print("\nNombre del Pokemon: ");
                    String nombre = sc.nextLine();
                    System.out.print("Tipo del Pokemon: ");
                    String tipo = sc.nextLine();
                    InsertarPokemon.insertarPokemon(nombre, tipo);
                    break;

                // BUSCAR
                case "2":
                    BuscarPokemon.buscarPokemon();

                    break;

                // ACTUALIZAR
                case "3":
                    UpdatePokemon.actualizar();

                    break;

                // BORRAR
                case "4":
                    BorrarPokemon.borrar();
                    break;

                // SALIR
                case "5":

                    System.out.println("\n¡Hasta luego, entrenador!");
                    return;

                default:
                    System.out.println("\nOpcion no valida.");
            }
        }
    }
}