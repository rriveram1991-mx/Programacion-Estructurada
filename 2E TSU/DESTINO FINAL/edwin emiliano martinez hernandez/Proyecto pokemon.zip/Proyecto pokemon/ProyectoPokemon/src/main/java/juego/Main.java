package juego;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int opcion = 0;

        do {
            System.out.println("\n=== JUEGO POKEMON ===");
            System.out.println("1. Registrar Pokemon a tu equipo");
            System.out.println("2. Actualizar Pokemon o Mochila");
            System.out.println("3. Eliminar Pokemon");
            System.out.println("4. Mostrar registros (Pokemones/Mochila)");
            System.out.println("5. Salir");
            System.out.print("Elige una opcion: ");
            opcion = leer.nextInt();
            leer.nextLine();

            switch (opcion) {
                case 1: registrarPokemon(leer); break;
                case 2: actualizarRegistros(leer); break;
                case 3: eliminarPokemon(leer); break;
                case 4: mostrarRegistros(leer); break;
                case 5: System.out.println("Saliendo..."); break;
                default: System.out.println("Opcion invalida.");
            }
        } while (opcion != 5);
    }

    public static void registrarPokemon(Scanner leer) {
        System.out.print("Nombre del Pokemon: ");
        String nombre = leer.nextLine();
        System.out.print("Tipo (Ej. Electrico): ");
        String tipo = leer.nextLine();

        try (Connection cxn = Conexion.getConnection()) {
            String sql = "INSERT INTO pokemones (nombre, tipo) VALUES (?, ?)";
            PreparedStatement ps = cxn.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, tipo);
            ps.executeUpdate();
            System.out.println("Pokemon registrado exitosamente.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void actualizarRegistros(Scanner leer) {
        System.out.println("1. Actualizar Pokemon\n2. Actualizar Mochila");
        int sub = leer.nextInt();
        leer.nextLine();

        try (Connection cxn = Conexion.getConnection()) {
            if (sub == 1) {
                System.out.print("ID del Pokemon a actualizar: ");
                int id = leer.nextInt();
                leer.nextLine();
                System.out.print("Nuevo nombre: ");
                String nombre = leer.nextLine();
                System.out.print("Nuevo tipo: ");
                String tipo = leer.nextLine();

                String sql = "UPDATE pokemones SET nombre = ?, tipo = ? WHERE id = ?";
                PreparedStatement ps = cxn.prepareStatement(sql);
                ps.setString(1, nombre);
                ps.setString(2, tipo);
                ps.setInt(3, id);
                ps.executeUpdate();
                System.out.println("Pokemon actualizado.");
            } else if (sub == 2) {
                System.out.print("ID del objeto en Mochila: ");
                int id = leer.nextInt();
                System.out.print("Nueva cantidad: ");
                int cant = leer.nextInt();

                String sql = "UPDATE mochilas SET cantidad = ? WHERE id = ?";
                PreparedStatement ps = cxn.prepareStatement(sql);
                ps.setInt(1, cant);
                ps.setInt(2, id);
                ps.executeUpdate();
                System.out.println("Mochila actualizada.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void eliminarPokemon(Scanner leer) {
        System.out.print("ID del Pokemon a eliminar: ");
        int id = leer.nextInt();

        try (Connection cxn = Conexion.getConnection()) {
            String sql = "DELETE FROM pokemones WHERE id = ?";
            PreparedStatement ps = cxn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Pokemon eliminado.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void mostrarRegistros(Scanner leer) {
        System.out.println("1. Ver Pokemones\n2. Ver Mochila");
        int sub = leer.nextInt();

        try (Connection cxn = Conexion.getConnection()) {
            if (sub == 1) {
                ResultSet rs = cxn.prepareStatement("SELECT * FROM pokemones").executeQuery();
                System.out.println("\nID | NOMBRE | TIPO");
                while (rs.next()) {
                    System.out.println(rs.getInt("id") + " | " + rs.getString("nombre") + " | " + rs.getString("tipo"));
                }
            } else if (sub == 2) {
                ResultSet rs = cxn.prepareStatement("SELECT * FROM mochilas").executeQuery();
                System.out.println("\nID | NOMBRE | CANTIDAD");
                while (rs.next()) {
                    System.out.println(rs.getInt("id") + " | " + rs.getString("nombre") + " | " + rs.getInt("cantidad"));
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}