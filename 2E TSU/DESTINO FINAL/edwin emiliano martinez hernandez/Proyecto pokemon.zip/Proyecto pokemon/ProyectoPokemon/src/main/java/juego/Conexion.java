package juego;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    public static Connection getConnection() {
        Connection cxn = null;
        try {
            String url = "jdbc:mysql://localhost:3306/juego_pokemon";
            String user = "root";
            String password = "12345678";

            cxn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println("Error de conexion: " + e.getMessage());
        }
        return cxn;
    }
}