package ProyectoP;
import CRUD.*;

import java.util.Scanner;

public class pokemonByP {
    public static void main(String[] args){
        Scanner lr=new Scanner(System.in);
        //pokedex que guarde pokemones los elimine los busque y los actualice y bolsa con objetos
         String name;
         String type;
         int idp;
         int idb;
         int wr;
         Boolean vf=true;
         Boolean v=true;
         int opc;
         while(v){
         System.out.println("1-pokedex");
         System.out.println("2-bolsa");
         System.out.println("3-salir");
         opc=lr.nextInt();
         if(opc==3){
             break;
         }
        try{switch (opc){
            case 1:
            vf=true;
            while(vf) {
                System.out.println("¡Bienvenido a la pokedex!");
                System.out.println("1-registrar tus pokemones");
                System.out.println("2-buscar pokemones");
                System.out.println("3-actualizar pokemones");
                System.out.println("4-eliminar pokemones");
                System.out.println("5-salir de la pokedex");
                int opcion = lr.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("Ingresa el nombre del pokemon");
                        lr.nextLine();
                        name = lr.nextLine();
                        System.out.println("Ingresa su tipo");
                        type = lr.nextLine();
                        System.out.println("Asigna su id");
                        idp = lr.nextInt();
                        insertPokemon.insertPokemon(name, type, idp);
                        break;
                    case 2:
                        System.out.println("ingresa la id del pokemon a buscar");
                        idb = lr.nextInt();
                        BuscarPokemon.BuscarPokemon(idb);
                        break;
                    case 3:
                        System.out.println("ingresa la id del pokemon que quieres actualizar");
                        wr = lr.nextInt();
                        lr.nextLine();
                        System.out.println("ingresa nuevo nombre");
                        name = lr.nextLine();
                        System.out.println("ingresa el tipo del pokemon");
                        type = lr.nextLine();
                        updatePokemon.updatePokemon(wr, name, type);
                        break;
                    case 4:
                        System.out.println("ingresa id del pokemon al que quieres eliminar");
                        wr = lr.nextInt();
                        deletePokemon.deletePokemon(wr);
                        break;
                    case 5:
                        vf = false;
                        System.out.println("saliendo....");
                        break;
                    }
                }
            break;
            case 2:
                vf=true;
                while(vf){
                System.out.println("1-Ver objetos");
                System.out.println("2-actualizar objetos");
                System.out.println("3-salir de la bolsa");
                int opcion=lr.nextInt();
                switch (opcion){
                    case 1:
                        BuscarBag.BuscarBag();
                        break;
                    case 2:
                        System.out.println("ingresa la id del objeto");
                        wr=lr.nextInt();
                        lr.nextLine();
                        System.out.println("ingresa nuevo nombre del objeto");
                        name=lr.nextLine();
                        System.out.println("ingresa cantidad de "+ name);
                        int cant=lr.nextInt();
                        ActualizarBag.ActualizarBag(wr,name,cant);
                        break;
                    case 3:
                        vf=false;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            }
        }
    }
}
