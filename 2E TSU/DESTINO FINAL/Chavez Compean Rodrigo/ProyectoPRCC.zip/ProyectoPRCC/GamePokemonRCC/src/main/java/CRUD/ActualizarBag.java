package CRUD;
import pokemonConexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
public class ActualizarBag {
    public static void ActualizarBag(int wr,String name,int cant){
        try{
            Connection cnx= conexion.getConnection();
            String sql= "UPDATE bag SET Objeto=?, Cantidad=? WHERE IDobj=?";
            PreparedStatement ps= cnx.prepareStatement(sql);
            ps.setInt(3,wr);
            ps.setString(1,name);
            ps.setInt(2,cant);
            ps.executeUpdate();
            System.out.println("Objeto Actualizado");
            System.out.println();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
