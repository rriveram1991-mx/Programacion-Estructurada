package pokemonConexion;
import java.sql.Connection;
import java.sql.DriverManager;
public class conexion {
    public static Connection getConnection() {
        Connection conexion = null;
        var BaseDatos = "pokemon";
        var url = "jdbc:mysql://localhost:3306/" + BaseDatos;
        var usuario = "root";
        var password = "2050";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(url, usuario, password);

        } catch (Exception e) {
            System.out.println("te vas a reme puñeton "+e.getMessage());
        }
        return conexion;
    }
    public static void main (String[] args){
        var conexion = pokemonConexion.conexion.getConnection();
        if (conexion!=null){
            System.out.println("bas bien chabal "+conexion);
        }else{
            System.out.println("vas reme chabal");
        }
    }
}
