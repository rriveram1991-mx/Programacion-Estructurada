package CRUD;
import pokemonConexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
public class deletePokemon {
    public static void deletePokemon(int wr){
        try{
            Connection cnx=conexion.getConnection();
            Statement st = cnx.createStatement();
            ResultSet rs =st.executeQuery("SELECT COUNT(*) AS total FROM pokedex");
            String sql ="DELETE FROM pokedex WHERE id=?";
            PreparedStatement ps= cnx.prepareStatement(sql);
            ps.setInt(1,wr);
            ps.executeUpdate();
            System.out.println("Pokemon eliminado");
            ResultSet rs2 = st.executeQuery("SELECT COUNT(*) AS total From pokedex");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
