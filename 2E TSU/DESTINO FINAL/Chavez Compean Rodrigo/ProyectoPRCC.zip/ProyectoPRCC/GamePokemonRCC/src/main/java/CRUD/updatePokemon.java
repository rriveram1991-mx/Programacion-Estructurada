package CRUD;
import pokemonConexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
public class updatePokemon {
    public static void updatePokemon(int wr,String name,String type){
        try{
            Connection cnx= conexion.getConnection();
            String sql= "UPDATE pokedex SET Pokemon=?, Tipo=? WHERE id=?";
            PreparedStatement ps= cnx.prepareStatement(sql);
            ps.setInt(3,wr);
            ps.setString(1,name);
            ps.setString(2,type);
            ps.executeUpdate();
            System.out.println("Pokemon actualizado en la pokedex");
            System.out.println();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
