package CRUD;
import pokemonConexion.conexion;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
public class BuscarPokemon {
    public static void BuscarPokemon(int idb) {
        Connection cnx = conexion.getConnection();
        try {
            Statement st = cnx.createStatement();
            ResultSet clCount = st.executeQuery("SELECT COUNT(*) as total FROM pokedex");
            if (clCount.next()) {
                int total = clCount.getInt("total");
                System.out.println("cantidad de pokemones registrados: " + total);
                System.out.println();

            }
            ResultSet info = st.executeQuery("SELECT * FROM pokedex");
            while (info.next()) {
                if(idb== info.getInt("id")) {
                    System.out.println("ID: " + info.getInt("id"));
                    System.out.println("Nombre: " + info.getString("Pokemon"));
                    System.out.println("Tipo: " + info.getString("Tipo"));
                }
            }
        } catch (Exception e) {
           System.out.println(e.getMessage());
        }
    }
}

