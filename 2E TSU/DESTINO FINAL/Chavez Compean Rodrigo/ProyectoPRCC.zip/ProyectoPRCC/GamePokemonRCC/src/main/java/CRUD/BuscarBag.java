package CRUD;
import pokemonConexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
public class BuscarBag {
    public static void BuscarBag() {
        Connection cnx = conexion.getConnection();
        try {
            Statement st = cnx.createStatement();
            ResultSet clCount = st.executeQuery("SELECT COUNT(*) as total FROM bag");
            if (clCount.next()) {
                int total = clCount.getInt("total");
                System.out.println("cantidad de objetos disponibles: " + total);
                System.out.println();

            }
            ResultSet info = st.executeQuery("SELECT * FROM bag");
            while (info.next()) {
                    System.out.println("ID: " + info.getInt("IDobj"));
                    System.out.println("objeto: " + info.getString("Objeto"));
                    System.out.println("Cantidad: " + info.getInt("Cantidad"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

