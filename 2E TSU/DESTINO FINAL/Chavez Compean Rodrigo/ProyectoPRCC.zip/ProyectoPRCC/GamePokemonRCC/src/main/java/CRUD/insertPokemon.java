package CRUD;
import pokemonConexion.conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
public class insertPokemon {
    public static void insertPokemon(String name, String type,int idp){
        Connection cnx = conexion.getConnection();
        try{
            String sql = "INSERT INTO pokedex (id, Pokemon, Tipo) VALUES (?, ?, ?)";
            PreparedStatement insert = cnx.prepareStatement(sql);
            insert.setInt(1, idp);
            insert.setString(2, name);
            insert.setString(3, type);
            insert.executeUpdate();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

}