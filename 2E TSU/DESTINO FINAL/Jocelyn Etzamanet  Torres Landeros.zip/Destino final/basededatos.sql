USE pokemon_game;

DROP TABLE IF EXISTS pokemones;
DROP TABLE IF EXISTS mochilas;

CREATE TABLE IF NOT EXISTS pokemones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50),
    tipo VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS mochilas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50),
    cantidad INT
);


INSERT INTO mochilas (nombre, cantidad)
VALUES ('Poción', 7);

SELECT * FROM mochilas;