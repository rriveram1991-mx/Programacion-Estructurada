package CRUD;

import java.sql.*;
import java.util.Scanner;

public class Create {

    public static void registrar(Connection con, Scanner sc) {
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT cantidad FROM mochilas LIMIT 1");

            int cantidad = 0;

            if (rs.next()) {
                cantidad = rs.getInt("cantidad");
            }

            System.out.println("Cantidad: " + cantidad);

            if (cantidad >= 5) {
                System.out.print("Nombre: ");
                String nombre = sc.nextLine();

                System.out.print("Tipo: ");
                String tipo = sc.nextLine();

                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO pokemones (nombre, tipo) VALUES (?, ?)");
                ps.setString(1, nombre);
                ps.setString(2, tipo);
                ps.executeUpdate();

                System.out.println("Pokemon registrado ✅");
            } else {
                System.out.println("No tienes suficientes pociones ❌");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
