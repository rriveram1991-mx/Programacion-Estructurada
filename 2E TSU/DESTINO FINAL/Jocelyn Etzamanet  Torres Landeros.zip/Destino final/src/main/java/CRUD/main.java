package CRUD;

import java.sql.Connection;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        Connection con = Conexion.conectar();
        Scanner sc = new Scanner(System.in);

        int opcion;

        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Registrar");
            System.out.println("2. Ver");
            System.out.println("3. Actualizar");
            System.out.println("4. Eliminar");
            System.out.println("5. Borrar todo");
            System.out.println("6. Salir");
            System.out.print("Opcion: ");

            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    Create.registrar(con, sc);
                    break;
                case 2:
                    Read.mostrar(con);
                    break;
                case 3:
                    update.actualizar(con, sc);
                    break;
                case 4:
                    delete.eliminar(con, sc);
                    break;
                case 5:
                    delete.borrarTodo(con);
                    break;
            }

        } while (opcion != 6);
    }
}
