package CRUD;

import java.sql.*;

public class Read {

    public static void mostrar(Connection con) {
        try {
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM pokemones");

            System.out.println("Pokemones:");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " - " +
                        rs.getString("nombre") + " - " +
                        rs.getString("tipo"));
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
