package CRUD;

import java.sql.*;
import java.util.Scanner;

public class delete {

    public static void eliminar(Connection con, Scanner sc) {
        try {
            System.out.print("ID a eliminar: ");
            int id = sc.nextInt();

            PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM pokemones WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("Eliminado 🗑️");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void borrarTodo(Connection con) {
        try {
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM mochilas");
            System.out.println("Objetos en mochila:");
            while (rs.next()) {
                System.out.println(rs.getString("nombre") + " - " + rs.getInt("cantidad"));
            }

            st.executeUpdate("DELETE FROM pokemones");
            st.executeUpdate("DELETE FROM mochilas");

            System.out.println("Todo eliminado 💥");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

