package CRUD;

import java.sql.*;
import java.util.Scanner;

public class update {

    public static void actualizar(Connection con, Scanner sc) {
        try {
            System.out.print("ID Pokemon: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Nuevo nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Nuevo tipo: ");
            String tipo = sc.nextLine();

            PreparedStatement ps = con.prepareStatement(
                    "UPDATE pokemones SET nombre=?, tipo=? WHERE id=?");
            ps.setString(1, nombre);
            ps.setString(2, tipo);
            ps.setInt(3, id);
            ps.executeUpdate();

            System.out.print("Nueva cantidad en mochila: ");
            int cantidad = sc.nextInt();

            PreparedStatement ps2 = con.prepareStatement(
                    "UPDATE mochilas SET cantidad=? WHERE id=1");
            ps2.setInt(1, cantidad);
            ps2.executeUpdate();

            System.out.println("Actualizado ✅");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
